package by.saskkeee.user;

import net.minecraft.client.MinecraftClient;
import zenith.zov.Zenith;
import zenith.zov.utility.discord.DiscordManager;

public class UserInfo {
    private static final String DEFAULT_USERNAME = "Player";
    private static final String DEFAULT_UID = "000000000000000000";
    private static final String DEFAULT_ROLE = "User";
    private static final String[] DEVELOPER_IDS = new String[]{"1391890033555935274", "987654321098765432"};
    private static final String[] PREMIUM_IDS = new String[]{"111111111111111111", "222222222222222222"};
    private static final String[] OWNER_IDS = new String[]{"333333333333333333", "444444444444444444"};

    public static String getUsername() {
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null
                && Zenith.INSTANCE.getDiscordManager().isRunning()
                && Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.userName() != null && !info.userName().isEmpty() && !info.userName().equals("Unknown")) {
                    return info.userName();
                }
            }
        } catch (Exception var1) {
        }

        return getMinecraftUsername();
    }

    public static String getUID() {
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null
                && Zenith.INSTANCE.getDiscordManager().isRunning()
                && Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.userId() != null && !info.userId().isEmpty() && !info.userId().equals("Unknown")) {
                    return info.userId();
                }
            }
        } catch (Exception var1) {
        }

        String minecraftUsername = getMinecraftUsername();
        return String.valueOf(Math.abs(minecraftUsername.hashCode()));
    }

    public static String getRole() {
        String username = getUsername();
        return isSpecialUser(username) ? "Developer" : "User";
    }

    private static boolean isSpecialUser(String username) {
        String[] specialUsers = new String[]{"admin", "developer", "owner"};

        for (String specialUser : specialUsers) {
            if (specialUser.equalsIgnoreCase(username)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isDeveloper(String userId) {
        for (String devId : DEVELOPER_IDS) {
            if (devId.equals(userId)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isPremium(String userId) {
        for (String premiumId : PREMIUM_IDS) {
            if (premiumId.equals(userId)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isOwner(String userId) {
        for (String ownerId : OWNER_IDS) {
            if (ownerId.equals(userId)) {
                return true;
            }
        }

        return false;
    }

    public static String getDisplayName() {
        return getUsername();
    }

    public static String getAvatarUrl() {
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null
                && Zenith.INSTANCE.getDiscordManager().isRunning()
                && Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.avatarUrl() != null && !info.avatarUrl().isEmpty() && !info.avatarUrl().equals("Unknown")) {
                    return info.avatarUrl();
                }
            }
        } catch (Exception var1) {
        }

        return null;
    }

    public static boolean isDiscordConnected() {
        try {
            return Zenith.INSTANCE.getDiscordManager() != null
                && Zenith.INSTANCE.getDiscordManager().isRunning()
                && Zenith.INSTANCE.getDiscordManager().getInfo() != null
                && Zenith.INSTANCE.getDiscordManager().getInfo().userName() != null
                && !Zenith.INSTANCE.getDiscordManager().getInfo().userName().equals("Unknown");
        } catch (Exception var1) {
            return false;
        }
    }

    public static String getDiscordStatus() {
        return isDiscordConnected() ? "Connected to Discord" : "Discord RPC not available";
    }

    public static String getMinecraftUsername() {
        return MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getName().getString() : "Unknown";
    }

    public static String getServerInfo() {
        return MinecraftClient.getInstance().getNetworkHandler() != null && MinecraftClient.getInstance().getNetworkHandler().getServerInfo() != null
            ? MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address
            : "Singleplayer";
    }

    public static boolean isOnline() {
        return MinecraftClient.getInstance().player != null;
    }
}
