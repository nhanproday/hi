package zenith.zov.base.comand.impl.args;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import zenith.zov.Zenith;

public class FriendArgumentType implements ArgumentType<String> {
    private static final List<String> EXAMPLES = Zenith.getInstance().getFriendManager().getItems().stream().limit(5L).toList();

    public static FriendArgumentType create() {
        return new FriendArgumentType();
    }

    public String parse(StringReader reader) throws CommandSyntaxException {
        String friend = reader.readString();
        if (!Zenith.getInstance().getFriendManager().isFriend(friend)) {
            throw new DynamicCommandExceptionType(name -> Text.literal("You don't have friend " + friend)).create(friend);
        } else {
            return friend;
        }
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(Zenith.getInstance().getFriendManager().getItems(), builder);
    }

    public Collection<String> getExamples() {
        return EXAMPLES;
    }
}
