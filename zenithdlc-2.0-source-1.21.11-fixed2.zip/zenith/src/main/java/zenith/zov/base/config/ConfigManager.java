package zenith.zov.base.config;

import com.darkmagician6.eventapi.EventManager;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import lombok.Generated;
import zenith.zov.Zenith;
import zenith.zov.utility.crypt.CryptUtility;

public class ConfigManager {
    public static final File configDirectory = new File(Zenith.DIRECTORY, "configs");
    ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final String shifr = "config";

    public ConfigManager() {
        configDirectory.mkdirs();
        this.loadConfig("current_config");
        EventManager.register(this);
        this.scheduler.scheduleAtFixedRate(() -> {
            try {
                this.saveConfig("current_config");
            } catch (Exception var2) {
            }
        }, 5L, 5L, TimeUnit.MINUTES);
    }

    public boolean loadConfig(String configName) {
        if (configName == null) {
            return false;
        } else {
            Config config = this.findConfig(configName);
            if (config == null) {
                return false;
            } else {
                try {
                    boolean var10;
                    try (BufferedReader reader = new BufferedReader(new FileReader(config.getFile()))) {
                        JsonParser parser = new JsonParser();
                        String encryptedDataBase64 = reader.readLine();
                        byte[] encryptedData = Base64.getDecoder().decode(encryptedDataBase64);
                        byte[] decryptedData = CryptUtility.decryptData(encryptedData, "config");
                        String json = new String(decryptedData, StandardCharsets.UTF_8);
                        JsonObject object = (JsonObject)parser.parse(json);
                        config.load(object);
                        var10 = true;
                    }

                    return var10;
                } catch (Exception var13) {
                    var13.printStackTrace();
                    return false;
                }
            }
        }
    }

    public boolean saveConfig(String configName) {
        try {
            if (configName == null) {
                return false;
            } else {
                Config config;
                if ((config = this.findConfig(configName)) == null) {
                    config = new Config(configName);
                }

                String contentPrettyPrint = new GsonBuilder().setPrettyPrinting().create().toJson(config.save());
                contentPrettyPrint = Base64.getEncoder().encodeToString(CryptUtility.encryptData(contentPrettyPrint.getBytes(), "config"));

                try {
                    FileWriter writer = new FileWriter(config.getFile());
                    writer.write(contentPrettyPrint);
                    writer.close();
                    return true;
                } catch (IOException var5) {
                    return false;
                }
            }
        } catch (Exception var6) {
            return false;
        }
    }

    public Config findConfig(String configName) {
        if (configName == null) {
            return null;
        } else {
            return new File(configDirectory, configName + "." + "Zenith".toLowerCase()).exists() ? new Config(configName) : null;
        }
    }

    public List<String> configNames() {
        File[] files = configDirectory.listFiles();
        List<String> names = new ArrayList<>();

        for (File file : files) {
            names.add(file.getName());
        }

        return names;
    }

    public boolean deleteConfig(String configName) {
        if (configName == null) {
            return false;
        } else {
            Config config;
            if ((config = this.findConfig(configName)) == null) {
                return false;
            } else {
                File f = config.getFile();
                return f.exists() && f.delete();
            }
        }
    }

    public void save() {
        this.scheduler.shutdown();
        this.saveConfig("current_config");
    }

    public String exportConfigEncryptedBase64(String configName) {
        try {
            if (configName == null) {
                configName = "current_config";
            }

            Config cfg = this.findConfig(configName);
            if (cfg == null) {
                cfg = new Config(configName);
            }

            String jsonPretty = new GsonBuilder().setPrettyPrinting().create().toJson(cfg.save());
            return Base64.getEncoder().encodeToString(CryptUtility.encryptData(jsonPretty.getBytes(StandardCharsets.UTF_8), "config"));
        } catch (Exception var4) {
            var4.printStackTrace();
            return null;
        }
    }

    public boolean importConfigEncryptedBase64(String encryptedBase64) {
        try {
            if (encryptedBase64 != null && !encryptedBase64.isBlank()) {
                byte[] encrypted = Base64.getDecoder().decode(encryptedBase64);
                byte[] decrypted = CryptUtility.decryptData(encrypted, "config");
                String json = new String(decrypted, StandardCharsets.UTF_8);
                JsonObject object = (JsonObject)JsonParser.parseString(json);
                Config cfg = new Config("current_config");
                cfg.load(object);
                this.saveConfig("current_config");
                return true;
            } else {
                return false;
            }
        } catch (Exception var7) {
            var7.printStackTrace();
            return false;
        }
    }

    @Generated
    public ScheduledExecutorService getScheduler() {
        return this.scheduler;
    }

    @Generated
    public String getShifr() {
        return "config";
    }
}
