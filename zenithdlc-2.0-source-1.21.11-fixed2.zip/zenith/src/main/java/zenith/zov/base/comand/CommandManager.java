package zenith.zov.base.comand;

import com.mojang.brigadier.CommandDispatcher;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommandSource;
import net.minecraft.command.CommandSource;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.base.comand.impl.ClipCommand;
import zenith.zov.base.comand.impl.ConfigCommand;
import zenith.zov.base.comand.impl.FakePlayerCommand;
import zenith.zov.base.comand.impl.FriendCommand;
import zenith.zov.base.comand.impl.MacroCommand;
import zenith.zov.base.comand.impl.RCTCommand;

public class CommandManager {
    private String prefix = ".";
    private final CommandDispatcher<CommandSource> dispatcher = new CommandDispatcher();
    private final CommandSource source = new ClientCommandSource(null, MinecraftClient.getInstance());
    private final List<CommandAbstract> commands = new ArrayList<>();

    public CommandManager() {
        this.registerCommand(new FriendCommand());
        this.registerCommand(new MacroCommand());
        this.registerCommand(new ClipCommand());
        this.registerCommand(new ConfigCommand());
        this.registerCommand(new RCTCommand());
        this.registerCommand(new FakePlayerCommand());
    }

    public void registerCommand(CommandAbstract command) {
        if (command != null) {
            command.register(this.dispatcher);
            this.commands.add(command);
        }
    }

    @Generated
    public String getPrefix() {
        return this.prefix;
    }

    @Generated
    public CommandDispatcher<CommandSource> getDispatcher() {
        return this.dispatcher;
    }

    @Generated
    public CommandSource getSource() {
        return this.source;
    }

    @Generated
    public List<CommandAbstract> getCommands() {
        return this.commands;
    }
}
