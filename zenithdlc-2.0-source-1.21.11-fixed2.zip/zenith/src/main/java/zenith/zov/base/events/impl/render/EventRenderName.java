package zenith.zov.base.events.impl.render;

import lombok.Generated;
import zenith.zov.base.events.callables.EventCancellable;

public final class EventRenderName extends EventCancellable {
}
