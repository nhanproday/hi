package zenith.zov.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.base.comand.impl.args.CommandArgumentType;
import zenith.zov.base.comand.impl.args.MacroArgumentType;
import zenith.zov.utility.game.other.MessageUtil;

public class MacroCommand extends CommandAbstract {
    public MacroCommand() {
        super("macro");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(
            arg("name", MacroArgumentType.create())
                .then(arg("bind", MacroArgumentType.create()).then(arg("command", CommandArgumentType.create()).executes(context -> {
                    String name = (String)context.getArgument("name", String.class);
                    String bind = (String)context.getArgument("bind", String.class);
                    String command = (String)context.getArgument("command", String.class);
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aMacro " + name + " created for key " + bind + " with command " + command);
                    return 1;
                })))
        );
        builder.then(literal("help").executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§6Usage: §r.macro <name> <bind> <command>");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§6Examples:§r");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§e.macro hata h /home 1 §7- create macro hata for key h with command /home 1");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§e.macro tp T /tp 100 64 100 §7- create macro tp for key T with command /tp 100 64 100");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§e.macro list §7- show all macros");
            return 1;
        }));
    }
}
