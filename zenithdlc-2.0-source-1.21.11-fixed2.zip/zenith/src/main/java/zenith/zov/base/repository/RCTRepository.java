package zenith.zov.base.repository;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zenith.zov.Zenith;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.base.notify.NotifyManager;
import zenith.zov.utility.game.player.PlayerInventoryUtil;
import zenith.zov.utility.game.server.ServerHandler;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.math.StopWatch;

public class RCTRepository implements IClient {
    private final StopWatch stopWatch = new StopWatch();
    private boolean lobby;
    private int anarchy;

    public RCTRepository() {
        EventManager.register(this);
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (this.anarchy != 0 && e.getPacket() instanceof GameMessageS2CPacket message && e.isReceive()) {
            String text = message.content().getString().toLowerCase();
            if (!text.contains("hub") && text.contains("failed")) {
                NotifyManager.getInstance().addNotification("[RCT]️", Text.literal(" Cannot enter this anarchy " + Formatting.RED + "server"));
                this.anarchy = 0;
            }
        }
    }

    @EventTarget
    public void onTick(EventUpdate e) {
        if (this.anarchy != 0) {
            ServerHandler serverHandler = Zenith.getInstance().getServerHandler();
            if (!serverHandler.isHolyWorld()) {
                this.anarchy = 0;
            } else {
                int currentAnarchy = serverHandler.getAnarchy();
                if (this.lobby) {
                    if (currentAnarchy == -1) {
                        this.lobby = false;
                    } else {
                        mc.player.networkHandler.sendChatCommand("hub");
                    }
                } else if (currentAnarchy == this.anarchy) {
                    this.anarchy = 0;
                } else {
                    if (mc.currentScreen instanceof GenericContainerScreen screen && screen.getTitle().getString().equals("Choose Light Anarchy:")) {
                        boolean secondScreen = ((GenericContainerScreenHandler)screen.getScreenHandler()).getInventory().size() < 10;
                        int[] slots = this.anarchy < 15
                            ? new int[]{0, 0}
                            : (this.anarchy < 33 ? new int[]{1, 14} : (this.anarchy < 48 ? new int[]{2, 32} : new int[]{3, 47}));
                        if (secondScreen) {
                            PlayerInventoryUtil.clickSlot(slots[0], 0, SlotActionType.PICKUP, false);
                        } else {
                            PlayerInventoryUtil.clickSlot(17 + this.anarchy - slots[1], 0, SlotActionType.PICKUP, false);
                        }

                        return;
                    }

                    if (this.stopWatch.every(500L)) {
                        mc.player.networkHandler.sendChatCommand("lite");
                    }
                }
            }
        }
    }

    public void reconnect(int anarchy) {
        if (anarchy > 0 && anarchy < 64) {
            this.anarchy = anarchy;
            this.lobby = true;
        } else {
            NotifyManager.getInstance().addNotification("[RCT]", Text.literal(" Incorrect " + Formatting.RED + "light"));
        }
    }
}
