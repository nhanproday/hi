package zenith.zov.base.rotation;

import java.util.function.Supplier;
import zenith.zov.base.rotation.mods.config.api.RotationConfig;
import zenith.zov.utility.game.player.rotation.Rotation;

public record RotationTarget(Rotation targetRotation, Supplier<Rotation> rotation, RotationConfig rotationConfigBack) {
}
