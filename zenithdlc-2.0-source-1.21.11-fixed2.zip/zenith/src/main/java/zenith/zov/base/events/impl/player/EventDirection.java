package zenith.zov.base.events.impl.player;

import com.darkmagician6.eventapi.events.Event;
import lombok.Generated;

public class EventDirection implements Event {
    private float yaw;
    private float pitch;

    @Generated
    public float getYaw() {
        return this.yaw;
    }

    @Generated
    public float getPitch() {
        return this.pitch;
    }

    @Generated
    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    @Generated
    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    @Generated
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof EventDirection other)) {
            return false;
        } else if (!other.canEqual(this)) {
            return false;
        } else {
            return Float.compare(this.getYaw(), other.getYaw()) != 0 ? false : Float.compare(this.getPitch(), other.getPitch()) == 0;
        }
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof EventDirection;
    }

    @Generated
    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + Float.floatToIntBits(this.getYaw());
        return result * 59 + Float.floatToIntBits(this.getPitch());
    }

    @Generated
    @Override
    public String toString() {
        return "EventDirection(yaw=" + this.getYaw() + ", pitch=" + this.getPitch() + ")";
    }

    @Generated
    public EventDirection(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }
}
