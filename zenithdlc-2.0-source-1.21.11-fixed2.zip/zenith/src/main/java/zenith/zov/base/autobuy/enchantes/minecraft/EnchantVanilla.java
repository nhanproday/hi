package zenith.zov.base.autobuy.enchantes.minecraft;

import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import zenith.zov.base.autobuy.enchantes.Enchant;

public class EnchantVanilla extends Enchant {
    public EnchantVanilla(String name, String checked, int minLevel) {
        super(name, checked, minLevel);
    }

    @Override
    public boolean isEnchanted(ItemStack stack) {
        if (this.minLevel <= 0) {
            return true;
        } else {
            ItemEnchantmentsComponent enchants = stack.getEnchantments();

            for (Entry<RegistryEntry<Enchantment>> entry : enchants.getEnchantmentEntries()) {
                String id = ((RegistryEntry)entry.getKey()).getKey().toString();
                if (id.contains(this.checked)) {
                    return entry.getIntValue() >= this.minLevel;
                }
            }

            return false;
        }
    }
}
