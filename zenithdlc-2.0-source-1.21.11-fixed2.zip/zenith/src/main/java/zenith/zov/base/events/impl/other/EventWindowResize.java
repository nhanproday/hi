package zenith.zov.base.events.impl.other;

import com.darkmagician6.eventapi.events.Event;
import lombok.Generated;

public class EventWindowResize implements Event {
}
