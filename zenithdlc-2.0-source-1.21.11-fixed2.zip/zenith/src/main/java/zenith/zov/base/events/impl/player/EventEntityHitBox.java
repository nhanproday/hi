package zenith.zov.base.events.impl.player;

import com.darkmagician6.eventapi.events.Event;
import lombok.Generated;
import net.minecraft.entity.Entity;

public class EventEntityHitBox implements Event {
    private Entity entity;
    private float size;

    @Generated
    public Entity getEntity() {
        return this.entity;
    }

    @Generated
    public float getSize() {
        return this.size;
    }

    @Generated
    public void setEntity(Entity entity) {
        this.entity = entity;
    }

    @Generated
    public void setSize(float size) {
        this.size = size;
    }

    @Generated
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof EventEntityHitBox other)) {
            return false;
        } else if (!other.canEqual(this)) {
            return false;
        } else if (Float.compare(this.getSize(), other.getSize()) != 0) {
            return false;
        } else {
            Object this$entity = this.getEntity();
            Object other$entity = other.getEntity();
            return this$entity == null ? other$entity == null : this$entity.equals(other$entity);
        }
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof EventEntityHitBox;
    }

    @Generated
    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + Float.floatToIntBits(this.getSize());
        Object $entity = this.getEntity();
        return result * 59 + ($entity == null ? 43 : $entity.hashCode());
    }

    @Generated
    @Override
    public String toString() {
        return "EventEntityHitBox(entity=" + this.getEntity() + ", size=" + this.getSize() + ")";
    }

    @Generated
    public EventEntityHitBox(Entity entity, float size) {
        this.entity = entity;
        this.size = size;
    }
}
