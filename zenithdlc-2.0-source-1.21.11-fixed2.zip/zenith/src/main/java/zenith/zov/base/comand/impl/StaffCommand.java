package zenith.zov.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import zenith.zov.Zenith;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.base.comand.impl.args.FriendArgumentType;
import zenith.zov.base.comand.impl.args.PlayerArgumentType;
import zenith.zov.utility.game.other.MessageUtil;

public class StaffCommand extends CommandAbstract {
    public StaffCommand() {
        super("friend");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            String name = (String)context.getArgument("player", String.class);
            if (Zenith.getInstance().getStaffManager().getItems().contains(name)) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN, "Already added " + name);
                return 1;
            } else {
                Zenith.getInstance().getStaffManager().add(name);
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "Added " + name);
                return 1;
            }
        })));
        builder.then(literal("remove").then(arg("player", FriendArgumentType.create()).executes(context -> {
            String nickname = (String)context.getArgument("player", String.class);
            Zenith.getInstance().getStaffManager().remove(nickname);
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, nickname + " removed from staff");
            return 1;
        })));
        builder.then(literal("list").executes(commandContext -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, Zenith.getInstance().getStaffManager().getItems().toString());
            return 1;
        }));
    }
}
