package zenith.zov.base.events.impl.player;

import lombok.Generated;
import zenith.zov.base.events.callables.EventCancellable;

public class EventRotate extends EventCancellable {
}
