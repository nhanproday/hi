package zenith.zov.base.events.impl.input;

import com.darkmagician6.eventapi.events.Event;
import lombok.Generated;
import net.minecraft.client.gui.screen.Screen;

public class EventSetScreen implements Event {
    private Screen screen;

    @Generated
    public EventSetScreen(Screen screen) {
        this.screen = screen;
    }

    @Generated
    public Screen getScreen() {
        return this.screen;
    }

    @Generated
    public void setScreen(Screen screen) {
        this.screen = screen;
    }

    @Generated
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof EventSetScreen other)) {
            return false;
        } else if (!other.canEqual(this)) {
            return false;
        } else {
            Object this$screen = this.getScreen();
            Object other$screen = other.getScreen();
            return this$screen == null ? other$screen == null : this$screen.equals(other$screen);
        }
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof EventSetScreen;
    }

    @Generated
    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $screen = this.getScreen();
        return result * 59 + ($screen == null ? 43 : $screen.hashCode());
    }

    @Generated
    @Override
    public String toString() {
        return "EventSetScreen(screen=" + this.getScreen() + ")";
    }
}
