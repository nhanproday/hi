package zenith.zov.base.comand.impl;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.UUID;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.nbt.NbtCompound;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.utility.game.other.MessageUtil;
import zenith.zov.utility.interfaces.IClient;

public class FakePlayerCommand extends CommandAbstract implements IClient {
    private boolean spawn = false;
    public static OtherClientPlayerEntity player = null;

    public FakePlayerCommand() {
        super("fakeplayer");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            this.spawn = !this.spawn;
            if (this.spawn) {
                if (mc.player == null || mc.world == null) {
                    return 1;
                }

                player = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "ZenithClient.cc"));
                player.copyPositionAndRotation(mc.player);
                player.setId(-673);
                player.copyFrom(mc.player);
                player.setHealth(20.0F);
                player.setAbsorptionAmount(16.0F);
                NbtCompound compoundTag = new NbtCompound();
                mc.player.writeCustomDataToNbt(compoundTag);
                player.readCustomDataFromNbt(compoundTag);
                mc.world.addEntity(player);
                player.tick();
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aSuccessfully spawned the fake player");
            } else {
                if (mc.player == null || mc.world == null || player == null) {
                    return 1;
                }

                mc.world.removeEntity(player.getId(), RemovalReason.DISCARDED);
                player = null;
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aSuccessfully removed the fake player");
            }

            return 1;
        });
    }
}
