package zenith.zov.base.events.impl.player;

import lombok.Generated;
import net.minecraft.entity.Entity;
import zenith.zov.base.events.callables.EventCancellable;

public final class EventAttack extends EventCancellable {
    private final Entity target;
    private final EventAttack.Action action;

    @Generated
    public Entity getTarget() {
        return this.target;
    }

    @Generated
    public EventAttack.Action getAction() {
        return this.action;
    }

    @Generated
    public EventAttack(Entity target, EventAttack.Action action) {
        this.target = target;
        this.action = action;
    }

    public static enum Action {
        POST,
        PRE;
    }
}
