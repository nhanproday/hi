package zenith.zov.base.events.impl.player;

import zenith.zov.base.events.callables.EventCancellable;

public class EventItemUseCooldown extends EventCancellable {
    private int cooldown;

    public EventItemUseCooldown(int cooldown) {
        this.cooldown = cooldown;
    }

    public int getCooldown() {
        return this.cooldown;
    }

    public void setCooldown(int cooldown) {
        this.cooldown = cooldown;
    }
}
