package zenith.zov.base.comand.impl;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import zenith.zov.Zenith;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.base.notify.NotifyManager;
import zenith.zov.base.repository.RCTRepository;
import zenith.zov.utility.game.server.ServerHandler;
import zenith.zov.utility.interfaces.IClient;

public class RCTCommand extends CommandAbstract implements IClient {
    private final RCTRepository repository = Zenith.getInstance().getRCTRepository();

    public RCTCommand() {
        super("rct");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(
            context -> {
                ServerHandler serverHandler = Zenith.getInstance().getServerHandler();
                if (!serverHandler.isHolyWorld()) {
                    NotifyManager.getInstance().addNotification("[RCT]", Text.literal(" Not working on this " + Formatting.RED + "server"));
                    return 1;
                } else if (serverHandler.isPvp()) {
                    NotifyManager.getInstance()
                        .addNotification("️[RCT]", Text.literal(" You are in " + Formatting.RED + "pvp" + Formatting.RESET + " mode"));
                    return 1;
                } else {
                    this.repository.reconnect(serverHandler.getAnarchy());
                    return 1;
                }
            }
        );
        builder.then(
            CommandAbstract.arg("anarchy", IntegerArgumentType.integer(1, 63))
                .executes(
                    context -> {
                        ServerHandler serverHandler = Zenith.getInstance().getServerHandler();
                        if (!serverHandler.isHolyWorld()) {
                            NotifyManager.getInstance().addNotification("[RCT]", Text.literal(" Not working on this " + Formatting.RED + "server"));
                            return 1;
                        } else if (serverHandler.isPvp()) {
                            NotifyManager.getInstance()
                                .addNotification("[RCT]️", Text.literal(" You are in " + Formatting.RED + "pvp" + Formatting.RESET + " mode"));
                            return 1;
                        } else {
                            int anarchy = (Integer)context.getArgument("anarchy", Integer.class);
                            this.repository.reconnect(anarchy);
                            return 1;
                        }
                    }
                )
        );
    }
}
