package zenith.zov.base.rotation.deeplearnig;

import lombok.Generated;

public class DeepLearningManager {
    private final MinaraiModel model = new MinaraiModel("model");
    private final MinaraiModel speedModer;
    private final MinaraiModel slowModel;

    public DeepLearningManager() {
        this.model.load();
        this.slowModel = new MinaraiModel("slow");
        this.slowModel.load();
        this.speedModer = new MinaraiModel("tf-0100");
        this.speedModer.load();
    }

    @Generated
    public MinaraiModel getModel() {
        return this.model;
    }

    @Generated
    public MinaraiModel getSpeedModer() {
        return this.speedModer;
    }

    @Generated
    public MinaraiModel getSlowModel() {
        return this.slowModel;
    }
}
