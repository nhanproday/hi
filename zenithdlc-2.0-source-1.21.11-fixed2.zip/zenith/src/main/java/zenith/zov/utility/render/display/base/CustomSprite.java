package zenith.zov.utility.render.display.base;

import lombok.Generated;
import net.minecraft.util.Identifier;
import zenith.zov.Zenith;

public class CustomSprite {
    private final Identifier texture;

    public CustomSprite(String path) {
        if (path.contains(":")) {
            this.texture = Identifier.of(path);
        } else if (path.contains("/")) {
            this.texture = Zenith.id(path);
        } else {
            this.texture = Zenith.id("icons/category/" + path);
        }
    }

    @Generated
    public Identifier getTexture() {
        return this.texture;
    }
}
