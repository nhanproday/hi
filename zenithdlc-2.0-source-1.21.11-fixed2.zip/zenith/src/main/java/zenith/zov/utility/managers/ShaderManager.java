package zenith.zov.utility.managers;

import lombok.Generated;
import zenith.zov.utility.math.TimerUtils;

public class ShaderManager {
    private final ShaderManager.ShaderTimer timer = new ShaderManager.ShaderTimer();

    public void onDisconnect() {
        this.timer.reset();
    }

    public void updateTime() {
        this.timer.update(1.0F);
    }

    @Generated
    public ShaderManager.ShaderTimer getTimer() {
        return this.timer;
    }

    public static class ShaderTimer {
        private final TimerUtils timer = new TimerUtils();
        private long passedTime = 0L;

        public ShaderTimer() {
            this.timer.reset();
        }

        public void reset() {
            this.passedTime = 0L;
            this.timer.reset();
        }

        public void update(float speed) {
            this.passedTime = this.passedTime + (long)((float)this.timer.getPassedTime() * speed);
            this.timer.reset();
        }

        @Generated
        public TimerUtils getTimer() {
            return this.timer;
        }

        @Generated
        public long getPassedTime() {
            return this.passedTime;
        }
    }
}
