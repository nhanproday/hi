package zenith.zov.utility.entity;

import java.awt.Color;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import zenith.zov.utility.interfaces.IClient;

public class FakePlayerEntity implements IClient {
    private final PlayerEntity originalEntity;
    private final String name;
    private final boolean isClone;
    private Vec3d position;
    private int id;
    private boolean spawned = false;
    private long spawnTime;

    public FakePlayerEntity(PlayerEntity originalEntity, String name, boolean isClone) {
        this.originalEntity = originalEntity;
        this.name = name;
        this.isClone = isClone;
        this.position = originalEntity.getPos();
        this.id = originalEntity.getId() + 1000000;
        this.spawnTime = System.currentTimeMillis();
    }

    public void spawnPlayer() {
        if (!this.spawned) {
            this.spawned = true;
            this.spawnTime = System.currentTimeMillis();
            if (this.originalEntity != null) {
                this.position = this.originalEntity.getPos();
            }
        }
    }

    public void despawnPlayer() {
        if (this.spawned) {
            this.spawned = false;
            this.position = Vec3d.ZERO;
        }
    }

    public void updatePosition(Vec3d newPosition) {
        this.position = newPosition;
    }

    public Vec3d getPos() {
        return this.position;
    }

    public int getId() {
        return this.id;
    }

    public boolean isClone() {
        return this.isClone;
    }

    public boolean isSpawned() {
        return this.spawned;
    }

    public long getSpawnTime() {
        return this.spawnTime;
    }

    public long getAge() {
        return System.currentTimeMillis() - this.spawnTime;
    }

    public double distanceTo(PlayerEntity other) {
        return this.position.distanceTo(other.getPos());
    }

    public double distanceTo(Vec3d pos) {
        return this.position.distanceTo(pos);
    }

    public Color cloneColor(float alpha) {
        int alphaValue = (int)(alpha * 255.0F);
        return new Color(255, 255, 255, Math.max(0, Math.min(255, alphaValue)));
    }

    public Color cloneColor(int time) {
        float alpha = Math.max(0.0F, Math.min(1.0F, (float)time / 1000.0F));
        return this.cloneColor(alpha);
    }

    public Color getFadeColor(float maxAlpha) {
        long age = this.getAge();
        float alpha = Math.max(0.0F, Math.min(maxAlpha, 1.0F - (float)age / 3000.0F));
        return this.cloneColor(alpha);
    }

    public PlayerEntity getOriginalEntity() {
        return this.originalEntity;
    }

    public String getName() {
        return this.name;
    }

    public float getWidth() {
        return this.originalEntity != null ? this.originalEntity.getWidth() : 0.6F;
    }

    public float getHeight() {
        return this.originalEntity != null ? this.originalEntity.getHeight() : 1.8F;
    }

    public boolean isInRange(double maxDistance) {
        return mc.player == null ? false : this.distanceTo(mc.player) <= maxDistance;
    }

    public boolean isExpired(long maxAge) {
        return this.getAge() > maxAge;
    }
}
