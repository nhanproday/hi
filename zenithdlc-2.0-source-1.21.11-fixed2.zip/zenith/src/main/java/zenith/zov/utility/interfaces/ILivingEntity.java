package zenith.zov.utility.interfaces;

public interface ILivingEntity {
    boolean zenith$isStaticPlayerEntity();
}
