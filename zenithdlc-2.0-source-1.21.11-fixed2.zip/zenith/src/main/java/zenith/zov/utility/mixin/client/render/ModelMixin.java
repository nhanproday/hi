package zenith.zov.utility.mixin.client.render;

import net.minecraft.client.model.Model;
import net.minecraft.client.render.entity.model.EndCrystalEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import zenith.zov.Zenith;
import zenith.zov.client.modules.impl.render.EntityModifierModule;

@Mixin({Model.class})
public abstract class ModelMixin {
    @ModifyArgs(
        method = {"render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;II)V"},
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/model/Model;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"
        )
    )
    private void render$render(Args args) {
        EntityModifierModule module = (EntityModifierModule)Zenith.getInstance().getModuleManager().getModule("EntityModifier");
        if (this instanceof EndCrystalEntityModel && module != null && module.isEnabled() && module.crystals.isEnabled()) {
            args.set(4, module.crystalColor.getColor().getRGB());
        }
    }
}
