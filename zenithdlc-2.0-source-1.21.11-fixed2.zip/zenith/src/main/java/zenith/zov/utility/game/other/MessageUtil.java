package zenith.zov.utility.game.other;

import java.awt.Color;
import lombok.Generated;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import zenith.zov.Zenith;
import zenith.zov.utility.interfaces.IMinecraft;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

public final class MessageUtil implements IMinecraft {
    public static final Text PREFIX = (Text)Text.of("[ %s ] ".formatted("Zenith"))
        .copy()
        .append(Text.of("★"))
        .getWithStyle(Style.EMPTY.withColor(ColorRGBA.BLUE.getRGB()))
        .getFirst();

    public static void displayMessage(MessageUtil.LogLevel level, String message) {
        if (mc.player != null) {
            Text icon = (Text)Text.of("[ %s ] ".formatted("Zenith"))
                .copy()
                .append(Text.of("★"))
                .getWithStyle(Style.EMPTY.withColor(Zenith.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB()))
                .getFirst();
            Text styledMessage = (Text)Text.of(message).copy().getWithStyle(getLevelStyle(level)).getFirst();
            mc.player.sendMessage(icon.copy().append(" ").append(styledMessage), false);
        }
    }

    public static void displayWarning(String message) {
        displayMessage(MessageUtil.LogLevel.WARN, message);
    }

    public static void displayError(String message) {
        displayMessage(MessageUtil.LogLevel.ERROR, message);
    }

    public static void displayInfo(String message) {
        displayMessage(MessageUtil.LogLevel.INFO, message);
    }

    private static Style getLevelStyle(MessageUtil.LogLevel level) {
        return Style.EMPTY.withColor(level.getColor().getRGB());
    }

    @Generated
    private MessageUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static enum LogLevel {
        WARN("Warning", new Color(247, 206, 59)),
        ERROR("Error", new Color(242, 79, 68)),
        INFO("Info", new Color(87, 126, 255));

        private final String level;
        private final Color color;

        @Generated
        public String getLevel() {
            return this.level;
        }

        @Generated
        public Color getColor() {
            return this.color;
        }

        @Generated
        private LogLevel(final String level, final Color color) {
            this.level = level;
            this.color = color;
        }
    }
}
