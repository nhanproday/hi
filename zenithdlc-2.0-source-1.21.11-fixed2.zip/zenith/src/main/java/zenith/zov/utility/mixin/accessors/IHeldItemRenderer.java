package zenith.zov.utility.mixin.accessors;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

public interface IHeldItemRenderer {
    void renderShaderItem(float var1, MatrixStack var2, VertexConsumerProvider var3, ClientPlayerEntity var4, int var5);
}
