package zenith.zov.utility.mixin.minecraft.entity;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import zenith.zov.Zenith;
import zenith.zov.utility.game.player.rotation.Rotation;
import zenith.zov.utility.interfaces.IMinecraft;

@Mixin({PlayerEntity.class})
public class PlayerEntityMixin {
    @Mutable
    float savedYaw;
    @Mutable
    float savedPitch;

    @Inject(
        method = {"tickMovement"},
        at = {@At("HEAD")}
    )
    private void tickMovement(CallbackInfo ci) {
    }

    @Inject(
        method = {"travel"},
        at = {@At("HEAD")}
    )
    public void fixElytra(CallbackInfo ci) {
        if (this instanceof ClientPlayerEntity player) {
            Rotation currentRotation = Zenith.getInstance().getRotationManager().getCurrentRotation();
            this.savedYaw = IMinecraft.mc.player.getYaw();
            this.savedPitch = IMinecraft.mc.player.getPitch();
            player.setYaw(currentRotation.getYaw());
            player.setPitch(currentRotation.getPitch());
        }
    }

    @Inject(
        method = {"travel"},
        at = {@At("RETURN")}
    )
    public void fixElytraEnd(CallbackInfo ci) {
        if (this instanceof ClientPlayerEntity player) {
            player.setYaw(this.savedYaw);
            player.setPitch(this.savedPitch);
        }
    }
}
