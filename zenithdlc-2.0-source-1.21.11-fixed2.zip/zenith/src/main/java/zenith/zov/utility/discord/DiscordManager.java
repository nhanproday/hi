package zenith.zov.utility.discord;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import lombok.Generated;
import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.DiscordEventHandlers.Builder;
import net.arikia.dev.drpc.callbacks.ReadyCallback;
import zenith.zov.Zenith;
import zenith.zov.client.modules.impl.misc.DiscordRPCModule;
import zenith.zov.utility.interfaces.IMinecraft;

public class DiscordManager implements IMinecraft {
    private boolean running = true;
    private boolean initialized = false;
    private DiscordManager.DiscordInfo info = new DiscordManager.DiscordInfo("Unknown", "", "");
    private ScheduledExecutorService executor;

    public void init() {
        if (!this.initialized) {
            try {
                DiscordEventHandlers handlers = new Builder()
                    .setReadyEventHandler(
                        new ReadyCallback() {
                            public void apply(DiscordUser user) {
                                DiscordManager.this.setInfo(
                                    new DiscordManager.DiscordInfo(
                                        user.username, "https://cdn.discordapp.com/avatars/" + user.userId + "/" + user.avatar + ".png", user.userId
                                    )
                                );
                                DiscordManager.this.updatePresence();
                            }
                        }
                    )
                    .setDisconnectedEventHandler((errorCode, message) -> this.running = false)
                    .setErroredEventHandler((errorCode, message) -> {
                    })
                    .build();
                DiscordRPC.discordInitialize("1396101952143757353", handlers, true);
                this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "DiscordRPC-Callback");
                    t.setDaemon(true);
                    return t;
                });
                this.executor.scheduleAtFixedRate(() -> {
                    try {
                        DiscordRPC.discordRunCallbacks();
                    } catch (Exception var1x) {
                    }
                }, 0L, 2L, TimeUnit.SECONDS);
                this.initialized = true;
            } catch (Exception var2) {
                this.running = false;
                this.initialized = false;
            }
        }
    }

    public void updatePresence() {
        if (this.running && this.initialized) {
            try {
                DiscordRPCModule discordModule = (DiscordRPCModule)Zenith.getInstance().getModuleManager().getModule("DiscordRPC");
                if (discordModule == null || !discordModule.isEnabled()) {
                    return;
                }

                net.arikia.dev.drpc.DiscordRichPresence.Builder builder = new net.arikia.dev.drpc.DiscordRichPresence.Builder("")
                    .setStartTimestamps(System.currentTimeMillis() / 1000L)
                    .setBigImage("https://s14.gifyu.com/images/bKm4m.jpg", "Zenith DLC");
                if (discordModule.isShowDetails()) {
                    String details = discordModule.getStatus();
                    if (mc.player != null) {
                        String playerName = mc.player.getName().getString();
                        int uid = Math.abs(playerName.hashCode()) % 10000 + 1;
                        details = details + " | UID: " + uid;
                    }

                    builder.setDetails(details);
                }

                DiscordRPC.discordUpdatePresence(builder.build());
            } catch (Exception var6) {
            }
        }
    }

    public void stopRPC() {
        if (this.running && this.initialized) {
            try {
                DiscordRPC.discordShutdown();
            } catch (Exception var10) {
            } finally {
                this.running = false;
                this.initialized = false;
                if (this.executor != null && !this.executor.isShutdown()) {
                    try {
                        this.executor.shutdown();
                        if (!this.executor.awaitTermination(5L, TimeUnit.SECONDS)) {
                            this.executor.shutdownNow();
                        }
                    } catch (InterruptedException var9) {
                        this.executor.shutdownNow();
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
    }

    public void forceUpdatePresence() {
        this.updatePresence();
    }

    @Generated
    public void setRunning(boolean running) {
        this.running = running;
    }

    @Generated
    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }

    @Generated
    public void setInfo(DiscordManager.DiscordInfo info) {
        this.info = info;
    }

    @Generated
    public void setExecutor(ScheduledExecutorService executor) {
        this.executor = executor;
    }

    @Generated
    public boolean isRunning() {
        return this.running;
    }

    @Generated
    public boolean isInitialized() {
        return this.initialized;
    }

    @Generated
    public DiscordManager.DiscordInfo getInfo() {
        return this.info;
    }

    @Generated
    public ScheduledExecutorService getExecutor() {
        return this.executor;
    }

    public static record DiscordInfo(String userName, String avatarUrl, String userId) {
    }
}
