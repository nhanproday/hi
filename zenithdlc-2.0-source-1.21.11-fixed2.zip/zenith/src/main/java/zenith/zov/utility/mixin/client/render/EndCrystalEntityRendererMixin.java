package zenith.zov.utility.mixin.client.render;

import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import zenith.zov.Zenith;
import zenith.zov.client.modules.impl.render.EntityModifierModule;

@Mixin({EndCrystalEntityRenderer.class})
public class EndCrystalEntityRendererMixin {
    @ModifyArgs(
        method = {"render"},
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/util/math/MatrixStack;scale(FFF)V"
        )
    )
    private void render$scale(Args args) {
        EntityModifierModule module = (EntityModifierModule)Zenith.getInstance().getModuleManager().getModule("EntityModifier");
        if (module != null && module.isEnabled() && module.crystals.isEnabled()) {
            float scale = module.crystalScale.getCurrent();
            args.set(0, scale);
            args.set(1, scale);
            args.set(2, scale);
        }
    }

    @ModifyArgs(
        method = {"render"},
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"
        )
    )
    private void modifyBounce(Args args) {
        EntityModifierModule module = (EntityModifierModule)Zenith.getInstance().getModuleManager().getModule("EntityModifier");
        if (module != null && module.isEnabled() && module.crystals.isEnabled()) {
            float bounce = module.crystalBounce.getCurrent();
            args.set(1, (Float)args.get(1) * bounce);
        }
    }
}
