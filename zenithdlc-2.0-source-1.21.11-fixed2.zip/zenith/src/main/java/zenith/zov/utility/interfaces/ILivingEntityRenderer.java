package zenith.zov.utility.interfaces;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;

public interface ILivingEntityRenderer {
    void zenith$render(LivingEntityRenderState var1, MatrixStack var2, VertexConsumerProvider var3, int var4);
}
