package zenith.zov.utility.mixin.client.render;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.render.entity.model.EndCrystalEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import zenith.zov.Zenith;
import zenith.zov.client.modules.impl.render.EntityModifierModule;

@Mixin({EndCrystalEntityModel.class})
public class EndCrystalEntityModelMixin {
    @ModifyExpressionValue(
        method = {"setAngles(Lnet/minecraft/client/render/entity/state/EndCrystalEntityRenderState;)V"},
        at = {@At(
            value = "FIELD",
            target = "Lnet/minecraft/client/render/entity/state/EndCrystalEntityRenderState;age:F",
            ordinal = 0
        )}
    )
    private float modifySpeed(float original) {
        EntityModifierModule module = (EntityModifierModule)Zenith.getInstance().getModuleManager().getModule("EntityModifier");
        return module != null && module.isEnabled() && module.crystals.isEnabled() ? original * module.crystalSpeed.getCurrent() : original;
    }
}
