package zenith.zov.utility.animation;

import net.minecraft.util.math.Vec3d;

public class PositionAnimation {
    private final float duration;
    private Vec3d startPos;
    private Vec3d targetPos;
    private Vec3d currentPos;
    private long startTime;
    private boolean animating;

    public PositionAnimation(float duration) {
        this.duration = duration;
        this.currentPos = Vec3d.ZERO;
        this.animating = false;
    }

    public void animate(Vec3d targetPos) {
        this.startPos = this.currentPos;
        this.targetPos = targetPos;
        this.startTime = System.currentTimeMillis();
        this.animating = true;
    }

    public void setInstant(Vec3d pos) {
        this.currentPos = pos;
        this.targetPos = pos;
        this.animating = false;
    }

    public Vec3d getCurrentPos() {
        if (!this.animating) {
            return this.currentPos;
        } else {
            long elapsed = System.currentTimeMillis() - this.startTime;
            float progress = Math.min(1.0F, (float)elapsed / this.duration);
            if (progress >= 1.0F) {
                this.currentPos = this.targetPos;
                this.animating = false;
                return this.currentPos;
            } else {
                double x = this.startPos.x + (this.targetPos.x - this.startPos.x) * (double)progress;
                double y = this.startPos.y + (this.targetPos.y - this.startPos.y) * (double)progress;
                double z = this.startPos.z + (this.targetPos.z - this.startPos.z) * (double)progress;
                this.currentPos = new Vec3d(x, y, z);
                return this.currentPos;
            }
        }
    }

    public boolean isAnimating() {
        return this.animating;
    }
}
