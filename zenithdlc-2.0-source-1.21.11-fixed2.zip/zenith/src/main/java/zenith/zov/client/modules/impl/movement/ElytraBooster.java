package zenith.zov.client.modules.impl.movement;

import lombok.Generated;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
    name = "ElytraBooster",
    category = Category.MOVEMENT,
    description = "Boosts your firework"
)
public final class ElytraBooster extends Module {
    public static final ElytraBooster INSTANCE = new ElytraBooster();
    private final ModeSetting mode = new ModeSetting("Mode", "");
    private final NumberSetting boost = new NumberSetting("Boost", 1.0F, 0.1F, 5.0F, 0.1F, () -> !this.mode.getValue().getName().equals("Custom"));
    private ModeSetting.Value custom = new ModeSetting.Value(this.mode, "Custom", "");
    private ModeSetting.Value auto = new ModeSetting.Value(this.mode, "Auto", "");

    private ElytraBooster() {
        this.mode.setValue(this.custom);
    }

    @Generated
    public ModeSetting getMode() {
        return this.mode;
    }

    @Generated
    public NumberSetting getBoost() {
        return this.boost;
    }

    @Generated
    public ModeSetting.Value getCustom() {
        return this.custom;
    }

    @Generated
    public ModeSetting.Value getAuto() {
        return this.auto;
    }
}
