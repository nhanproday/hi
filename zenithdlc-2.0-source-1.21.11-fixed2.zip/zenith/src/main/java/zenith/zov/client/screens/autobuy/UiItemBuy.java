package zenith.zov.client.screens.autobuy;

import java.util.Locale;
import lombok.Generated;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.item.ItemStack;
import zenith.zov.Zenith;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.client.screens.autobuy.items.AutoInventoryItem;
import zenith.zov.client.screens.autobuy.items.ExtendAutoInventoryItem;
import zenith.zov.client.screens.menu.settings.api.MenuSetting;
import zenith.zov.client.screens.menu.settings.impl.MenuSliderSetting;
import zenith.zov.utility.game.other.MouseButton;
import zenith.zov.utility.render.display.TextBox;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.Rect;
import zenith.zov.utility.render.display.base.UIContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

public class UiItemBuy {
    private final AutoInventoryItem itemBuy;
    private final TextBox sumTextBox;
    private Rect bounds;
    private final Animation enableAnimation = new Animation(200L, Easing.QUAD_IN_OUT);
    private final MenuSliderSetting menuSliderSetting;

    public UiItemBuy(AutoInventoryItem itemBuy) {
        this.itemBuy = itemBuy;
        this.sumTextBox = new TextBox(new Vector2f(0.0F, 0.0F), Fonts.MEDIUM.getFont(7.0F), "Amount", 50.0F);
        this.sumTextBox.setCharFilter(TextBox.CharFilter.NUMBERS_ONLY);
        this.sumTextBox.setMaxLength(11);
        this.sumTextBox.setText(String.valueOf(itemBuy.getMaxSumBuy()));
        this.sumTextBox.setCursor(this.sumTextBox.getText().length());
        this.menuSliderSetting = new MenuSliderSetting(
            new NumberSetting(
                "Quantity",
                1.0F,
                1.0F,
                (float)itemBuy.getItemBuy().getItemStack().getMaxCount(),
                1.0F,
                (oldValue, newValue) -> itemBuy.setCountBuy((int)newValue)
            )
        );
    }

    public void renderSlotBar(CustomDrawContext ctx, float x, float y, float itemSize, BorderRadius borderRadius) {
        this.bounds = new Rect(x + 0.1F, y + 0.1F, itemSize - 0.2F, itemSize - 0.2F);
        this.renderSlot(ctx, x, y, itemSize, borderRadius);
    }

    private void renderSlot(CustomDrawContext ctx, float x, float y, float itemSize, BorderRadius borderRadius) {
        this.enableAnimation.update(this.itemBuy.isSelected());
        Font countFont = Fonts.MEDIUM.getFont(6.0F);
        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        ItemStack stack = this.itemBuy.getItemBuy().getItemStack();
        ColorRGBA slotColor = this.itemBuy.isSelected() ? theme.getColor() : theme.getForegroundGray();
        float round = 4.0F;
        ctx.drawRoundedRect(x, y, itemSize, itemSize, borderRadius, slotColor);
        if (!stack.isEmpty()) {
            ctx.pushMatrix();
            ctx.getMatrices().translate((double)x + ((double)itemSize - 12.8) / 2.0, (double)y + ((double)itemSize - 12.8) / 2.0, 0.0);
            ctx.getMatrices().scale(0.8F, 0.8F, 1.0F);
            ctx.drawItem(stack, 0, 0);
            ctx.popMatrix();
            if (this.itemBuy.getCountBuy() > 1) {
                String countText = "x" + this.itemBuy.getCountBuy();
                float countWidth = countFont.width(countText);
                float countX = x + itemSize - countWidth - 0.5F;
                float countY = y + itemSize - countFont.height() - 2.0F;
                ctx.drawText(countFont, countText, countX, countY, theme.getWhite());
            }
        }
    }

    public void renderSettings(UIContext ctx, float mouseX, float mouseY, float x, float y, float itemSize) {
        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        this.renderSlot(ctx, x, y, itemSize, BorderRadius.all(4.0F));
        Font textFont = Fonts.MEDIUM.getFont(7.0F);
        ctx.drawRoundedRect(x + 20.0F + 8.0F, y, 172.0F, itemSize, BorderRadius.all(4.0F), theme.getForegroundLight());
        ctx.drawText(
            textFont,
            this.itemBuy.getItemBuy().getDisplayName(),
            x + 20.0F + 8.0F + (172.0F - textFont.width(this.itemBuy.getItemBuy().getDisplayName())) / 2.0F,
            y + 8.0F,
            theme.getColor()
        );
        ctx.drawRoundedRect(x + 200.0F - 65.0F, y + 20.0F + 8.0F, 65.0F, itemSize, BorderRadius.all(4.0F), theme.getForegroundLight());
        this.sumTextBox.render(ctx, x + 200.0F - 65.0F + 8.0F, y + 20.0F + 8.0F + 8.0F, theme.getColor(), theme.getGray());
        this.sumTextBox.setWidth(50.0F);
        ctx.drawRoundedRect(x, y + 20.0F + 8.0F, 127.0F, itemSize, BorderRadius.all(4.0F), theme.getForegroundLight());
        ctx.drawText(textFont, "Buy this item for amount up to:", x + 8.0F, y + 20.0F + 8.0F + 8.0F, theme.getWhite());
        this.menuSliderSetting
            .render(
                ctx, mouseX, mouseY, x, y + 20.0F + 8.0F + 20.0F + 8.0F, 200.0F, 1.0F, 1.0F, theme.getColor(), theme.getWhite(), theme.getWhiteGray(), theme
            );
        if (!this.sumTextBox.isEmpty()) {
            String cleanText = this.sumTextBox.getText().replaceAll(",", "");
            this.sumTextBox.setText(String.format(Locale.US, "%,d", Long.parseLong(cleanText)));
            this.itemBuy.setMaxSumBuy(Long.parseLong(cleanText));
        }

        if (this.itemBuy instanceof ExtendAutoInventoryItem extendAutoInventoryItem) {
            System.out.println("YES");
            float settingX = x + 200.0F + 8.0F + 8.0F + 8.0F + 8.0F;
            float settingWidth = 150.0F;
            ctx.drawRoundedRect(settingX, y - 8.0F, settingWidth, 200.0F, BorderRadius.all(8.0F), theme.getForegroundColor());
            ctx.drawText(Fonts.MEDIUM.getFont(7.0F), "Additional Settings", settingX + 50.0F, y, theme.getWhite());
            float settingY = y + 20.0F;

            for (MenuSetting menuSetting : extendAutoInventoryItem.getEnchants()) {
                menuSetting.render(
                    ctx, mouseX, mouseY, settingX, settingY, settingWidth, 1.0F, 1.0F, theme.getColor(), theme.getWhite(), theme.getWhiteGray(), theme
                );
                settingY += menuSetting.getHeight() + 16.0F;
            }
        }
    }

    public boolean onMouseClicked(double mouseX, double mouseY, MouseButton button, boolean selected) {
        if (this.bounds != null && this.bounds.contains(mouseX, mouseY)) {
            if (button == MouseButton.LEFT) {
                this.itemBuy.toggleSelected();
            }

            return true;
        } else {
            if (selected) {
                this.sumTextBox.onMouseClicked(mouseX, mouseY, button);
                this.menuSliderSetting.onMouseClicked(mouseX, mouseY, button);
                if (this.itemBuy instanceof ExtendAutoInventoryItem extendAutoInventoryItem) {
                    for (MenuSetting menuSetting : extendAutoInventoryItem.getEnchants()) {
                        menuSetting.onMouseClicked(mouseX, mouseY, button);
                    }
                }
            }

            return false;
        }
    }

    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        this.menuSliderSetting.onMouseReleased(mouseX, mouseY, button);
        if (this.itemBuy instanceof ExtendAutoInventoryItem extendAutoInventoryItem) {
            for (MenuSetting menuSetting : extendAutoInventoryItem.getEnchants()) {
                menuSetting.onMouseReleased(mouseX, mouseY, button);
            }
        }
    }

    public boolean charTyped(char codePoint, int modifiers) {
        return this.sumTextBox.charTyped(codePoint, modifiers);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.sumTextBox.keyPressed(keyCode, scanCode, modifiers);
    }

    public String getName() {
        return this.itemBuy.getItemBuy().getDisplayName();
    }

    public void setBounds(float x, float y, float width, float height) {
        this.bounds = new Rect(x, y, width, height);
    }

    @Generated
    public AutoInventoryItem getItemBuy() {
        return this.itemBuy;
    }

    @Generated
    public Rect getBounds() {
        return this.bounds;
    }

    @Generated
    public void setBounds(Rect bounds) {
        this.bounds = bounds;
    }
}
