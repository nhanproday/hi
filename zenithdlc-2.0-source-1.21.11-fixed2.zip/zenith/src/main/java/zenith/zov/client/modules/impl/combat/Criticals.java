package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventAttack;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.math.MathUtil;

@ModuleAnnotation(
    name = "Criticals",
    category = Category.COMBAT,
    description = "Criticals bypass"
)
public class Criticals extends Module implements IClient {
    public static final Criticals INSTANCE = new Criticals();
    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Grim");

    private Criticals() {
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (!mc.player.isTouchingWater()) {
            if (this.mode.get().equals("Grim") && !mc.player.isOnGround() && mc.player.fallDistance == 0.0F) {
                mc.player.fallDistance = (float)MathUtil.getRandom(1.0E-5F, 1.0E-4F);
            }
        }
    }
}
