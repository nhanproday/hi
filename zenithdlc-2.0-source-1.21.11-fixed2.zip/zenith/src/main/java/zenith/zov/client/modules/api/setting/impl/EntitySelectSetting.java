package zenith.zov.client.modules.api.setting.impl;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Type;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import zenith.zov.client.modules.api.setting.Setting;

public class EntitySelectSetting extends Setting {
    private List<String> entitiesById;
    private static final Gson gson = new Gson();

    public void setEntitiesById(List<String> entitiesById) {
        this.entitiesById = entitiesById;
    }

    public EntitySelectSetting(String name, List<String> entitiesById) {
        this(name, entitiesById, () -> true);
    }

    public EntitySelectSetting(String name, List<String> entitiesById, Supplier<Boolean> visible) {
        super(name);
        this.entitiesById = entitiesById;
    }

    public List<String> getEntitiesById() {
        return this.entitiesById;
    }

    public void add(String s) {
        this.entitiesById.add(s);
    }

    public void remove(String s) {
        this.entitiesById.remove(s);
    }

    public boolean contains(String s) {
        return this.entitiesById.contains(s);
    }

    public void add(EntityType<?> entityType) {
        this.add(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public void remove(EntityType<?> entityType) {
        this.remove(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public boolean contains(EntityType<?> entityType) {
        return this.contains(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public boolean contains(Entity entity) {
        return this.contains(entity.getType());
    }

    public void clear() {
        this.entitiesById.clear();
    }

    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.add(String.valueOf(this.name), gson.toJsonTree(this.getEntitiesById()));
    }

    @Override
    public void load(JsonObject propertiesObject) {
        Type listType = (new TypeToken<List<String>>() {
        }).getType();
        JsonElement jsonElement = propertiesObject.get(String.valueOf(this.name));
        if (jsonElement != null && jsonElement.isJsonArray()) {
            List<String> list = (List<String>)gson.fromJson(jsonElement, listType);
            this.setEntitiesById(list);
        }
    }
}
