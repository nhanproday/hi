package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.math.Timer;

@ModuleAnnotation(
    name = "AntiBot",
    category = Category.COMBAT,
    description = ""
)
public final class AntiBot extends Module {
    public static final AntiBot INSTANCE = new AntiBot();
    private final List<PlayerEntity> bots = new ArrayList<>();
    private final Timer timer = new Timer();

    private AntiBot() {
    }

    @EventTarget
    public void onTick(EventUpdate event) {
        if (mc.player != null && mc.world != null) {
            if (this.timer.finished(10000L) && !this.bots.isEmpty()) {
                this.bots.clear();
                this.timer.reset();
            }

            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player != null && player != mc.player && this.armorCheck(player) && !this.bots.contains(player)) {
                    this.bots.add(player);
                }
            }
        }
    }

    private boolean armorCheck(PlayerEntity entity) {
        return this.getArmor(entity, 3).getItem() == Items.LEATHER_HELMET && this.isNotColored(entity, 3) && !this.getArmor(entity, 3).hasEnchantments()
            || this.getArmor(entity, 2).getItem() == Items.LEATHER_CHESTPLATE && this.isNotColored(entity, 2) && !this.getArmor(entity, 2).hasEnchantments()
            || this.getArmor(entity, 1).getItem() == Items.LEATHER_LEGGINGS && this.isNotColored(entity, 1) && !this.getArmor(entity, 1).hasEnchantments()
            || this.getArmor(entity, 0).getItem() == Items.LEATHER_BOOTS && this.isNotColored(entity, 0) && !this.getArmor(entity, 0).hasEnchantments()
            || this.getArmor(entity, 2).getItem() == Items.IRON_CHESTPLATE && !this.getArmor(entity, 2).hasEnchantments()
            || this.getArmor(entity, 1).getItem() == Items.IRON_LEGGINGS && !this.getArmor(entity, 1).hasEnchantments();
    }

    private ItemStack getArmor(PlayerEntity entity, int slot) {
        return entity.getInventory().getArmorStack(slot);
    }

    private boolean isNotColored(PlayerEntity entity, int slot) {
        return !this.getArmor(entity, slot).contains(DataComponentTypes.DYED_COLOR);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (!this.bots.isEmpty()) {
            this.bots.clear();
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (!this.bots.isEmpty()) {
            this.bots.clear();
        }
    }

    public boolean isBot(PlayerEntity player) {
        return this.bots.contains(player);
    }
}
