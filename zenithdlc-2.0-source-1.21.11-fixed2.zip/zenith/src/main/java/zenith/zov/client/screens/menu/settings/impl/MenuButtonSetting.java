package zenith.zov.client.screens.menu.settings.impl;

import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.modules.api.setting.impl.ButtonSetting;
import zenith.zov.client.screens.menu.settings.api.MenuSetting;
import zenith.zov.utility.game.other.MouseButton;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.Rect;
import zenith.zov.utility.render.display.base.UIContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

public class MenuButtonSetting extends MenuSetting {
    private final ButtonSetting button;
    private final Animation animHovered = new Animation(200L, 0.0F, Easing.QUAD_IN_OUT);
    Rect bounds;

    public MenuButtonSetting(ButtonSetting button) {
        this.button = button;
    }

    @Override
    public void render(
        UIContext ctx,
        float mouseX,
        float mouseY,
        float x,
        float settingY,
        float moduleWidth,
        float alpha,
        float animEnable,
        ColorRGBA themeColor,
        ColorRGBA textColor,
        ColorRGBA descriptionColor,
        Theme theme
    ) {
        this.bounds = new Rect(x + 8.0F, settingY, moduleWidth - 16.0F, 16.0F);
        ctx.drawRoundedRect(x + 8.0F, settingY, moduleWidth - 16.0F, 16.0F, BorderRadius.all(4.0F), theme.getForegroundColor().mulAlpha(alpha));
        ctx.drawRoundedRect(x + 8.0F, settingY, moduleWidth - 16.0F, 16.0F, BorderRadius.all(4.0F), theme.getForegroundStroke().mulAlpha(alpha));
        ctx.drawText(
            Fonts.MEDIUM.getFont(7.0F),
            this.button.getName(),
            x + (moduleWidth - Fonts.MEDIUM.getWidth(this.button.getName(), 7.0F)) / 2.0F,
            settingY + 5.0F,
            textColor
        );
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (this.bounds != null && this.bounds.contains(mouseX, mouseY) && button == MouseButton.LEFT) {
            this.button.toggle();
        }
    }

    @Override
    public float getWidth() {
        return 0.0F;
    }

    @Override
    public float getHeight() {
        return 16.0F;
    }

    @Override
    public boolean isVisible() {
        return true;
    }
}
