package zenith.zov.client.modules.api;

import com.darkmagician6.eventapi.EventManager;
import com.google.gson.JsonObject;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Generated;
import org.jetbrains.annotations.NotNull;
import zenith.zov.base.events.impl.other.EventModuleToggle;
import zenith.zov.client.modules.api.setting.Setting;
import zenith.zov.utility.interfaces.IClient;

public class Module implements IClient, Comparable<Module> {
    protected ModuleAnnotation info = this.getClass().getAnnotation(ModuleAnnotation.class);
    private String name = this.info.name();
    private final Category category = this.info.category();
    private volatile boolean enabled = false;
    private int keyCode = -1;

    protected Module() {
    }

    public void setToggled(boolean state) {
        if (state) {
            this.onEnable();
        } else {
            this.onDisable();
        }

        this.enabled = state;
    }

    public void toggle() {
        this.enabled = !this.enabled;
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public void onEnable() {
        EventManager.register(this);
        EventManager.call(new EventModuleToggle(this, this.enabled));
    }

    public void onDisable() {
        EventManager.unregister(this);
        EventManager.call(new EventModuleToggle(this, this.enabled));
    }

    public List<Setting> getSettings() {
        return Arrays.stream(this.getClass().getDeclaredFields()).map(field -> {
            try {
                field.setAccessible(true);
                return field.get(this);
            } catch (IllegalAccessException var3) {
                var3.printStackTrace();
                return null;
            }
        }).filter(field -> field instanceof Setting).map(field -> (Setting)field).collect(Collectors.toList());
    }

    public JsonObject save() {
        JsonObject object = new JsonObject();
        object.addProperty("enabled", this.enabled);
        object.addProperty("keyCode", this.keyCode);
        JsonObject propertiesObject = new JsonObject();

        for (Setting setting : this.getSettings()) {
            setting.safe(propertiesObject);
        }

        object.add("Settings", propertiesObject);
        return object;
    }

    public void load(JsonObject object) {
        try {
            if (object != null) {
                if (object.has("enabled")) {
                    boolean enable = object.get("enabled").getAsBoolean();
                    if (enable && !this.isEnabled()) {
                        this.toggle();
                    }

                    if (!enable && this.isEnabled()) {
                        this.toggle();
                    }
                }

                if (object.has("keyCode")) {
                    this.keyCode = object.get("keyCode").getAsInt();
                }

                for (Setting setting : this.getSettings()) {
                    String valueOf = setting.getName();
                    JsonObject propertiesObject = object.getAsJsonObject("Settings");
                    if (propertiesObject != null && propertiesObject.has(valueOf)) {
                        setting.load(propertiesObject);
                    }
                }
            }
        } catch (Exception var6) {
            var6.printStackTrace();
        }
    }

    public int compareTo(@NotNull Module o) {
        return o.getName().compareTo(this.name);
    }

    @Generated
    public ModuleAnnotation getInfo() {
        return this.info;
    }

    @Generated
    public String getName() {
        return this.name;
    }

    @Generated
    public Category getCategory() {
        return this.category;
    }

    @Generated
    public boolean isEnabled() {
        return this.enabled;
    }

    @Generated
    public int getKeyCode() {
        return this.keyCode;
    }

    @Generated
    public void setInfo(ModuleAnnotation info) {
        this.info = info;
    }

    @Generated
    public void setName(String name) {
        this.name = name;
    }

    @Generated
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Generated
    public void setKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }

    @Generated
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Module other)) {
            return false;
        } else if (!other.canEqual(this)) {
            return false;
        } else if (this.isEnabled() != other.isEnabled()) {
            return false;
        } else if (this.getKeyCode() != other.getKeyCode()) {
            return false;
        } else {
            Object this$info = this.getInfo();
            Object other$info = other.getInfo();
            if (this$info == null ? other$info == null : this$info.equals(other$info)) {
                Object this$name = this.getName();
                Object other$name = other.getName();
                if (this$name == null ? other$name == null : this$name.equals(other$name)) {
                    Object this$category = this.getCategory();
                    Object other$category = other.getCategory();
                    return this$category == null ? other$category == null : this$category.equals(other$category);
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof Module;
    }

    @Generated
    @Override
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + (this.isEnabled() ? 79 : 97);
        result = result * 59 + this.getKeyCode();
        Object $info = this.getInfo();
        result = result * 59 + ($info == null ? 43 : $info.hashCode());
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $category = this.getCategory();
        return result * 59 + ($category == null ? 43 : $category.hashCode());
    }

    @Generated
    @Override
    public String toString() {
        return "Module(info="
            + this.getInfo()
            + ", name="
            + this.getName()
            + ", category="
            + this.getCategory()
            + ", enabled="
            + this.isEnabled()
            + ", keyCode="
            + this.getKeyCode()
            + ")";
    }
}
