package zenith.zov.client.screens.menu.elements.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.Vector2f;
import zenith.zov.Zenith;
import zenith.zov.base.cloud.CloudConfigService;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.screens.menu.elements.api.AbstractMenuElement;
import zenith.zov.utility.game.other.MessageUtil;
import zenith.zov.utility.game.other.MouseButton;
import zenith.zov.utility.render.display.TextBox;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.Rect;
import zenith.zov.utility.render.display.base.UIContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

public class MenuConfigElement extends AbstractMenuElement {
    private TextBox idField;
    private Rect bounds;
    private Rect copyBtn;
    private Rect cloudCreateBtn;
    private Rect cloudLoadBtn;
    private float cachedHeight = 72.0F;

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, Font font, float x, float y, float moduleWidth, float alpha, int colum) {
        if (this.idField == null) {
            this.idField = new TextBox(new Vector2f(0.0F, 0.0F), Fonts.MEDIUM.getFont(7.0F), "Cloud ID", 160.0F);
        }

        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA bg = theme.getForegroundColor().mulAlpha(alpha);
        ColorRGBA bg2 = theme.getForegroundDark().mulAlpha(alpha);
        this.bounds = new Rect(x, y, moduleWidth, this.getHeight());
        ctx.drawRoundedRect(x, y, moduleWidth, this.getHeight(), BorderRadius.all(8.0F), bg2);
        DrawUtil.drawRoundedBorder(
            ctx.getMatrices(), x, y, moduleWidth, this.getHeight(), -0.1F, BorderRadius.all(8.0F), theme.getForegroundStroke().mulAlpha(alpha)
        );
        float headerH = 22.0F;
        ctx.drawRoundedRect(x, y, moduleWidth, headerH, BorderRadius.top(8.0F, 8.0F), bg);
        DrawUtil.drawRoundedBorder(
            ctx.getMatrices(), x, y, moduleWidth, headerH, -0.1F, BorderRadius.top(8.0F, 8.0F), theme.getForegroundStroke().mulAlpha(alpha)
        );
        ctx.drawText(Fonts.ICONS.getFont(5.5F), "W", x + 8.0F, y + 9.0F, theme.getColor().mulAlpha(alpha));
        ctx.drawText(font, "Cloud Configs", x + 18.0F, y + 9.0F, theme.getWhite().mulAlpha(alpha));
        float pad = 8.0F;
        float rowY = y + headerH + pad;
        ctx.drawText(font, "ID", x + pad, rowY, theme.getWhiteGray().mulAlpha(alpha));
        float inputX = x + pad + 26.0F;
        float copyW = 44.0F;
        float inputW = Math.max(120.0F, moduleWidth - inputX - pad - (copyW + 6.0F));
        float inputH = 20.0F;
        ctx.drawRoundedRect(inputX, rowY - 2.0F, inputW, inputH, BorderRadius.all(6.0F), theme.getForegroundColor().mulAlpha(alpha));
        DrawUtil.drawRoundedBorder(
            ctx.getMatrices(), inputX, rowY - 2.0F, inputW, inputH, -0.1F, BorderRadius.all(6.0F), theme.getForegroundStroke().mulAlpha(alpha)
        );
        this.idField.setWidth(inputW - 8.0F);
        this.idField
            .render(
                ctx, inputX + 4.0F, rowY + (inputH - font.height()) / 2.0F - 0.5F, theme.getWhite().mulAlpha(alpha), theme.getWhite().mulAlpha(alpha * 0.5F)
            );
        this.copyBtn = new Rect(inputX + inputW + 6.0F, rowY - 2.0F, copyW, inputH);
        this.drawButton(ctx, this.copyBtn, "Copy", theme, alpha);
        float btnY = rowY + inputH + 6.0F;
        float btnW = 64.0F;
        float btnH = 18.0F;
        this.cloudCreateBtn = new Rect(inputX, btnY, btnW, btnH);
        this.cloudLoadBtn = new Rect(inputX + btnW + 6.0F, btnY, btnW, btnH);
        this.drawButton(ctx, this.cloudCreateBtn, "Create", theme, alpha);
        this.drawButton(ctx, this.cloudLoadBtn, "Load", theme, alpha);
        this.cachedHeight = btnY + btnH + pad - y;
    }

    private void drawButton(UIContext ctx, Rect r, String label, Theme theme, float alpha) {
        ctx.drawRoundedRect(r.x(), r.y(), r.width(), r.height(), BorderRadius.all(6.0F), theme.getForegroundColor().mulAlpha(alpha));
        DrawUtil.drawRoundedBorder(
            ctx.getMatrices(), r.x(), r.y(), r.width(), r.height(), -0.1F, BorderRadius.all(6.0F), theme.getForegroundStroke().mulAlpha(alpha)
        );
        Font f = Fonts.MEDIUM.getFont(7.0F);
        float tx = r.x() + (r.width() - f.width(label)) / 2.0F;
        float ty = r.y() + (r.height() - f.height()) / 2.0F;
        ctx.drawText(f, label, tx, ty, theme.getWhite().mulAlpha(alpha));
    }

    @Override
    public float getHeight() {
        return this.cachedHeight;
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (this.bounds != null && this.idField != null) {
            this.idField.onMouseClicked(mouseX, mouseY, button);
        }

        if (this.copyBtn != null && this.copyBtn.contains(mouseX, mouseY) && button.getButtonIndex() == 0) {
            String id = this.idField != null ? this.idField.getText() : "";
            if (!id.isBlank()) {
                MinecraftClient.getInstance().keyboard.setClipboard(id);
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aCopied ID to clipboard");
            }
        } else if (this.cloudCreateBtn != null && this.cloudCreateBtn.contains(mouseX, mouseY) && button.getButtonIndex() == 0) {
            String export = Zenith.getInstance().getConfigManager().exportConfigEncryptedBase64("current_config");
            if (export != null) {
                try {
                    CloudConfigService cloud = new CloudConfigService("http://104.164.55.190:8080");
                    String id = cloud.uploadConfig(export);
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aCloud saved. Share ID: §f" + id);
                    this.idField.setText(id);
                } catch (Exception var11) {
                    MessageUtil.displayMessage(MessageUtil.LogLevel.WARN, "§cCloud save failed");
                }
            }
        } else if (this.cloudLoadBtn != null && this.cloudLoadBtn.contains(mouseX, mouseY) && button.getButtonIndex() == 0) {
            String id = this.idField.getText().trim();
            if (!id.isBlank()) {
                try {
                    CloudConfigService cloud = new CloudConfigService("http://104.164.55.190:8080");
                    String payload = cloud.downloadConfig(id);
                    boolean ok = Zenith.getInstance().getConfigManager().importConfigEncryptedBase64(payload);
                    if (ok) {
                        MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aCloud loaded: §f" + id);
                    } else {
                        MessageUtil.displayMessage(MessageUtil.LogLevel.WARN, "§cCloud load failed");
                    }
                } catch (Exception var10) {
                    MessageUtil.displayMessage(MessageUtil.LogLevel.WARN, "§cCloud load error");
                }
            }
        }
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
    }

    @Override
    public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.idField != null && this.idField.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        return this.idField != null && this.idField.charTyped(chr, modifiers);
    }

    @Override
    public Category getCategory() {
        return Category.CONFIGS;
    }

    @Override
    public String getName() {
        return "Cloud Configs";
    }
}
