package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import java.util.List;
import zenith.zov.Zenith;
import zenith.zov.base.events.impl.render.EventFog;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ColorSetting;
import zenith.zov.client.modules.api.setting.impl.MultiBooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
    name = "WorldTweaks",
    description = "",
    category = Category.RENDER
)
public final class WorldTweaks extends Module {
    public final MultiBooleanSetting modeSetting = MultiBooleanSetting.create("Settings", List.of("Lighting", "Fog", "Time"));
    public final NumberSetting brightSetting = new NumberSetting("Lighting", 1.0F, 0.0F, 1.0F, 0.1F, () -> this.modeSetting.isEnable(0));
    private final ColorSetting colorFog = new ColorSetting("Fog Color", Zenith.getInstance().getThemeManager().getCurrentTheme().getColor());
    public final NumberSetting distanceSetting = new NumberSetting("Fog Distance", 80.0F, 10.0F, 255.0F, 5.0F, () -> this.modeSetting.isEnable(1));
    public final NumberSetting timeSetting = new NumberSetting("Time of Day", 12.0F, 0.0F, 24.0F, 1.0F, () -> this.modeSetting.isEnable(2));
    public static final WorldTweaks INSTANCE = new WorldTweaks();

    private WorldTweaks() {
    }

    @EventTarget
    public void onFog(EventFog e) {
        if (this.modeSetting.isEnable(1)) {
            e.setDistance(this.distanceSetting.getCurrent());
            e.setColor(this.colorFog.getIntColor());
            e.setCancelled(true);
        }
    }
}
