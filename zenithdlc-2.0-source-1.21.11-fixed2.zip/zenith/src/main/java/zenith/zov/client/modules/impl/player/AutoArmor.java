package zenith.zov.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;

@ModuleAnnotation(
    name = "AutoArmor",
    category = Category.PLAYER,
    description = "Automatically equips armor"
)
public final class AutoArmor extends Module implements IMinecraft {
    public static final AutoArmor INSTANCE = new AutoArmor();
    private final NumberSetting delay = new NumberSetting("Delay", 25.0F, 1.0F, 1000.0F, 1.0F);
    private long lastEquipTime = 0L;

    private AutoArmor() {
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player != null && mc.world != null) {
            if (!this.isMoving()) {
                long currentTime = System.currentTimeMillis();
                if (!((float)(currentTime - this.lastEquipTime) < this.delay.getCurrent())) {
                    for (int i = 0; i < 4; i++) {
                        ItemStack currentArmor = mc.player.getInventory().getArmorStack(i);
                        if (currentArmor.isEmpty()) {
                            for (int j = 0; j < 36; j++) {
                                ItemStack stack = mc.player.getInventory().getStack(j);
                                if (!stack.isEmpty() && stack.getItem() instanceof ArmorItem) {
                                    ArmorItem armorItem = (ArmorItem)stack.getItem();
                                    if (this.getArmorSlotIndex(armorItem) == i) {
                                        int slotToEquip = j;
                                        if (j < 9) {
                                            slotToEquip = j + 36;
                                        }

                                        mc.interactionManager.clickSlot(0, slotToEquip, 0, SlotActionType.QUICK_MOVE, mc.player);
                                        this.lastEquipTime = currentTime;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean isMoving() {
        return mc.player.input.movementForward != 0.0F || mc.player.input.movementSideways != 0.0F;
    }

    private int getArmorSlotIndex(ArmorItem armor) {
        String itemName = armor.toString().toLowerCase();
        if (itemName.contains("helmet") || itemName.contains("skull")) {
            return 3;
        } else if (itemName.contains("chestplate") || itemName.contains("tunic")) {
            return 2;
        } else if (itemName.contains("leggings") || itemName.contains("pants")) {
            return 1;
        } else {
            return !itemName.contains("boots") && !itemName.contains("shoes") ? 0 : 0;
        }
    }
}
