package zenith.zov.client.modules.impl.misc;

import lombok.Generated;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ColorSetting;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

@ModuleAnnotation(
    name = "AH Helper",
    category = Category.MISC,
    description = "helper for finding cheap items"
)
public final class AHHelper extends Module {
    public static final AHHelper INSTANCE = new AHHelper();
    private final ColorSetting cheapSlotColor = new ColorSetting("Cheap Color", new ColorRGBA(64, 255, 64, 140));
    private final ColorSetting goodSlotColor = new ColorSetting("Good Deal Color", new ColorRGBA(255, 255, 64, 140));

    private AHHelper() {
    }

    public void renderCheat(DrawContext context, Slot slot) {
        context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, this.cheapSlotColor.getIntColor());
    }

    public void renderGood(DrawContext context, Slot slot) {
        context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, this.goodSlotColor.getIntColor());
    }

    @Generated
    public ColorSetting getCheapSlotColor() {
        return this.cheapSlotColor;
    }

    @Generated
    public ColorSetting getGoodSlotColor() {
        return this.goodSlotColor;
    }
}
