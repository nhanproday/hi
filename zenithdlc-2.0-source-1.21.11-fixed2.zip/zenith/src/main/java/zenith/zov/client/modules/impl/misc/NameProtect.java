package zenith.zov.client.modules.impl.misc;

import zenith.zov.Zenith;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;

@ModuleAnnotation(
    name = "NameProtect",
    category = Category.MISC,
    description = "Protects player names"
)
public final class NameProtect extends Module {
    public static final NameProtect INSTANCE = new NameProtect();
    private final BooleanSetting hideFriends = new BooleanSetting("Hide Friends", false);

    private NameProtect() {
    }

    public static String getCustomName() {
        Module module = INSTANCE;
        return module != null && module.isEnabled() ? "ZENITHDLC" : mc.player.getNameForScoreboard();
    }

    public static String getCustomName(String originalName) {
        Module module = INSTANCE;
        if (module != null && module.isEnabled() && mc.player != null) {
            String me = mc.player.getNameForScoreboard();
            if (originalName.contains(me)) {
                return originalName.replace(me, "ZENITHDLC");
            } else {
                if (module instanceof NameProtect nameProtect && nameProtect.hideFriends.isEnabled()) {
                    for (String friend : Zenith.getInstance().getFriendManager().getItems()) {
                        if (originalName.contains(friend)) {
                            return originalName.replace(friend, "ZENITHDLC");
                        }
                    }
                }

                return originalName;
            }
        } else {
            return originalName;
        }
    }
}
