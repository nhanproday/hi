package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import zenith.zov.base.events.impl.player.EventMove;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.math.Timer;

@ModuleAnnotation(
    name = "AirStuck",
    category = Category.MOVEMENT,
    description = "Air Stuck"
)
public class AirStuck extends Module implements IClient {
    public static final AirStuck INSTANCE = new AirStuck();
    public Vec3d pos;
    public Vec3d prevPos;
    private World lastWorld;
    private final Timer freezeTimer = new Timer();
    private boolean prevReallyWorld = false;
    private boolean prevGliding = false;

    private AirStuck() {
    }

    @Override
    public void onEnable() {
        this.prevPos = this.pos = new Vec3d(mc.getEntityRenderDispatcher().camera.getPos().toVector3f());
        this.lastWorld = mc.player.getWorld();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.lastWorld = null;
        super.onDisable();
    }

    @EventTarget
    public void onMove(EventMove event) {
        boolean isReallyWorld = zenith.getServerHandler().getServer().equals("ReallyWorld");
        if (!isReallyWorld) {
            event.setMovePos(Vec3d.ZERO);
        } else {
            boolean isGliding = mc.player.isGliding();
            int freezeTicks = isGliding ? 250 : 10;
            if (this.freezeTimer.getElapsedTime() < (long)(freezeTicks * 50)) {
                event.setMovePos(Vec3d.ZERO);
            }
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.world != null && mc.player != null && mc.player.getWorld() == this.lastWorld) {
            boolean currReallyWorld = zenith.getServerHandler().getServer().equals("ReallyWorld") || zenith.getServerHandler().getServer().equals("FunTime");
            boolean currGliding = mc.player.isGliding();
            if (currReallyWorld != this.prevReallyWorld || currGliding != this.prevGliding) {
                this.freezeTimer.reset();
                this.prevReallyWorld = currReallyWorld;
                this.prevGliding = currGliding;
            }

            if (currReallyWorld) {
                int freezeTicks = currGliding ? 250 : 10;
                int resetTicks = currGliding ? 40 : 10;
                if (this.freezeTimer.getElapsedTime() >= (long)((freezeTicks + resetTicks) * 50)) {
                    this.freezeTimer.reset();
                }
            }
        } else {
            this.setEnabled(false);
        }
    }
}
