package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.game.other.MessageUtil;
import zenith.zov.utility.interfaces.IMinecraft;

@ModuleAnnotation(
    name = "ClanUpgrade",
    category = Category.MISC,
    description = "Automatic clan upgrade"
)
public final class ClanUpgrade extends Module implements IMinecraft {
    public static final ClanUpgrade INSTANCE = new ClanUpgrade();
    private static final float PITCH_FOR_PLACING = 90.0F;
    private static final float YAW_FOR_PLACING = 0.0F;
    private float originalPitch = 0.0F;
    private float originalYaw = 0.0F;
    private boolean rotationChanged = false;

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player != null && mc.world != null && mc.interactionManager != null) {
            ItemStack heldItem = mc.player.getStackInHand(Hand.MAIN_HAND);
            if (heldItem.getItem() != Items.REDSTONE) {
                MessageUtil.displayError("Take redstone in hand!");
            } else {
                BlockPos targetPos = mc.player.getBlockPos();
                BlockState stateAtTargetPos = mc.world.getBlockState(targetPos);
                if (!this.rotationChanged) {
                    this.originalPitch = mc.player.getPitch();
                    this.originalYaw = mc.player.getYaw();
                    this.rotationChanged = true;
                }

                mc.player.setPitch(90.0F);
                mc.player.setYaw(0.0F);
                if (stateAtTargetPos.isAir()) {
                    this.tryPlaceRedstone(targetPos);
                } else if (stateAtTargetPos.getBlock() == Blocks.REDSTONE_WIRE) {
                    this.tryBreakRedstone(targetPos);
                }
            }
        }
    }

    private void tryPlaceRedstone(BlockPos posToPlaceAt) {
        BlockPos supportBlockPos = posToPlaceAt.down();
        BlockState supportBlockState = mc.world.getBlockState(supportBlockPos);
        if (supportBlockState.isSolid()) {
            Vec3d hitVec = new Vec3d(
                (double)supportBlockPos.getX() + 0.5, (double)supportBlockPos.getY() + 1.0, (double)supportBlockPos.getZ() + 0.5
            );
            BlockHitResult rayTraceResult = new BlockHitResult(hitVec, Direction.UP, supportBlockPos, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, rayTraceResult);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void tryBreakRedstone(BlockPos posToBreak) {
        mc.interactionManager.attackBlock(posToBreak, Direction.UP);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (this.rotationChanged && mc.player != null) {
            mc.player.setPitch(this.originalPitch);
            mc.player.setYaw(this.originalYaw);
            this.rotationChanged = false;
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.rotationChanged = false;
        if (mc.player != null) {
            this.originalPitch = mc.player.getPitch();
            this.originalYaw = mc.player.getYaw();
        }
    }
}
