package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
    name = "StunMace",
    description = "Break shield with axe mid-air, hit with mace, then return to original slot",
    category = Category.COMBAT
)
public class StunMace extends Module {
    private final NumberSetting axeSlot = new NumberSetting("Axe Slot", 1.0F, 0.0F, 8.0F, 1.0F);
    private final NumberSetting maceSlot = new NumberSetting("Mace Slot", 2.0F, 0.0F, 8.0F, 1.0F);
    private final NumberSetting fallDistance = new NumberSetting("Fall Distance", 2.0F, 1.0F, 10.0F, 1.0F);
    private final NumberSetting returnSlot = new NumberSetting("Return Slot", 0.0F, 0.0F, 8.0F, 1.0F);
    private boolean hasTriggered = false;

    public StunMace() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player != null && mc.world != null && mc.interactionManager != null) {
            if (mc.player.isOnGround()) {
                this.hasTriggered = false;
            } else if (!(mc.player.fallDistance < this.fallDistance.getCurrent()) && !this.hasTriggered) {
                PlayerEntity target = this.getTarget();
                if (target != null && target.isAlive()) {
                    this.hasTriggered = true;
                    mc.player.getInventory().setSelectedSlot((int)this.axeSlot.getCurrent());
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                    mc.player.getInventory().setSelectedSlot((int)this.maceSlot.getCurrent());
                    mc.player.setCurrentHand(Hand.MAIN_HAND);
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                    mc.player.getInventory().setSelectedSlot((int)this.returnSlot.getCurrent());
                }
            }
        }
    }

    private PlayerEntity getTarget() {
        Entity var2 = mc.targetedEntity;
        return var2 instanceof PlayerEntity ? (PlayerEntity)var2 : null;
    }
}
