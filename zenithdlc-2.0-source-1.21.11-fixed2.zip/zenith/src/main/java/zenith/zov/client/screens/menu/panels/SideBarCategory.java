package zenith.zov.client.screens.menu.panels;

import lombok.Generated;
import net.minecraft.util.math.MathHelper;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.client.modules.api.Category;
import zenith.zov.utility.render.display.base.UIContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

public class SideBarCategory {
    private final Category category;
    private final Animation animationSwitch;

    public SideBarCategory(Category category) {
        this.category = category;
        this.animationSwitch = new Animation(200L, category == Category.COMBAT ? 1.0F : 0.0F, Easing.LINEAR);
    }

    public void render(
        UIContext ctx,
        float x,
        float y,
        float width,
        float height,
        float sidebarProgress,
        boolean selected,
        ColorRGBA textColor,
        ColorRGBA textColorDisable,
        ColorRGBA iconColorDisable,
        ColorRGBA primary
    ) {
        this.animationSwitch.animateTo(selected ? 1.0F : 0.0F);
        this.animationSwitch.update();
        ColorRGBA mixColor = iconColorDisable.mix(primary, this.animationSwitch.getValue());
        ColorRGBA mixColorText = textColorDisable.mix(textColor, this.animationSwitch.getValue());
        Font font = Fonts.ICONS.getFont(7.0F);
        float offestY = (height - font.height()) / 2.0F;
        float scale = MathHelper.lerp(sidebarProgress, 1.0F, 0.8F);
        float iconWidth = font.width(this.category.getIcon());
        ctx.pushMatrix();
        ctx.getMatrices()
            .translate(x + 8.0F + iconWidth / 2.0F + (float)(this.category == Category.PLAYER ? 1 : 0), y + offestY + font.height() / 2.0F, 0.0F);
        ctx.getMatrices().scale(scale, scale, 1.0F);
        ctx.getMatrices().translate(-(x + 8.0F + iconWidth / 2.0F), -(y + offestY + font.height() / 2.0F), 0.0F);
        ctx.drawText(Fonts.ICONS.getFont(7.0F), this.category.getIcon(), x + 8.0F, y + offestY, mixColor);
        ctx.popMatrix();
        Font categoryFont = Fonts.MEDIUM.getFont(7.0F);
        ctx.drawText(categoryFont, this.category.getName(), x + 8.0F + iconWidth * scale + 6.0F, y + (height - font.height()) / 2.0F, mixColorText);
    }

    @Generated
    public Category getCategory() {
        return this.category;
    }
}
