package zenith.zov.client.modules.impl.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
    name = "SwingAnimation",
    category = Category.RENDER,
    description = "Custom swing animations"
)
public final class SwingAnimation extends Module {
    public static final SwingAnimation INSTANCE = new SwingAnimation();
    public ModeSetting animationMode = new ModeSetting("Mode", "Normal", "First", "Second", "Third", "Fourth", "Fifth");
    public NumberSetting swingPower = new NumberSetting("Power", 5.0F, 1.0F, 10.0F, 0.05F);
    public final BooleanSetting onlyAura = new BooleanSetting("Only with Aura", false);

    private SwingAnimation() {
    }

    public void renderSwordAnimation(MatrixStack matrices, float swingProgress, float equipProgress, Arm arm) {
        String var5 = this.animationMode.get();
        switch (var5) {
            case "Normal": {
                matrices.translate(0.56F, -0.52F, -0.72F);
                float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -60.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(g * -30.0F));
                break;
            }
            case "First":
                if (swingProgress > 0.0F) {
                    float gx = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                    matrices.translate(0.56F, equipProgress * -0.2F - 0.5F, -0.7F);
                    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F));
                    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(gx * -85.0F));
                    matrices.translate(-0.1F, 0.28F, 0.2F);
                    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85.0F));
                } else {
                    float n = -0.4F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                    float m = 0.2F * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) (Math.PI * 2));
                    float f1 = -0.2F * MathHelper.sin(swingProgress * (float) Math.PI);
                    matrices.translate(n, m, f1);
                    this.applyEquipOffset(matrices, arm, equipProgress);
                    this.applySwingOffset(matrices, arm, swingProgress);
                }
                break;
            case "Second": {
                float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                this.applyEquipOffset(matrices, arm, 0.0F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110.0F + 20.0F * g));
                break;
            }
            case "Third": {
                float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                this.applyEquipOffset(matrices, arm, 0.0F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-30.0F * (1.0F - g) - 30.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110.0F));
                break;
            }
            case "Fourth": {
                float g = MathHelper.sin(swingProgress * (float) Math.PI);
                this.applyEquipOffset(matrices, arm, 0.0F);
                matrices.translate(0.1F, -0.2F, -0.3F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30.0F * g - 36.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(25.0F * g));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(12.0F));
                break;
            }
            case "Fifth": {
                float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
                this.applyEquipOffset(matrices, arm, 0.0F);
                matrices.translate(0.0F, -0.2F, -0.4F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-120.0F * g - 3.0F));
            }
        }
    }

    private void applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate((float)i * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
    }

    private void applySwingOffset(MatrixStack matrices, Arm arm, float swingProgress) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        float f = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)i * (45.0F + f * -20.0F)));
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)i * g * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -80.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float)i * -45.0F));
    }
}
