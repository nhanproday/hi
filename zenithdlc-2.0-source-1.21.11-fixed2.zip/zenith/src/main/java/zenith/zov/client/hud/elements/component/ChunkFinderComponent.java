package zenith.zov.client.hud.elements.component;

import java.util.Set;
import net.minecraft.util.math.ChunkPos;
import zenith.zov.Zenith;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.hud.elements.draggable.DraggableHudElement;
import zenith.zov.client.modules.impl.render.ChunkFinder;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

public class ChunkFinderComponent extends DraggableHudElement {
    private final Animation widthAnimation = new Animation(200L, Easing.QUAD_IN_OUT);
    private final Animation heightAnimation = new Animation(200L, Easing.QUAD_IN_OUT);

    public ChunkFinderComponent(
        String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align
    ) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        if (ChunkFinder.INSTANCE.isEnabled()) {
            float iconSize = 8.0F;
            float verticalPadding = 8.0F;
            float iconTextSpacing = 6.0F;
            float cellPadding = 8.0F;
            float borderRadius = 4.0F;
            float itemSpacing = 4.0F;
            Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
            Font font = Fonts.MEDIUM.getFont(7.0F);
            Font iconFont = Fonts.ICONS.getFont(7.0F);
            ColorRGBA mainBgColor = theme.getForegroundColor();
            ColorRGBA highlightBgColor = theme.getForegroundLight();
            ColorRGBA iconColor = theme.getColor();
            ColorRGBA textColor = theme.getWhite();
            ColorRGBA grayTextColor = theme.getGrayLight();
            ColorRGBA susChunkColor = new ColorRGBA(0, 255, 0, 255);
            ColorRGBA traderChunkColor = new ColorRGBA(255, 165, 0, 255);
            Set<ChunkPos> flaggedChunks = ChunkFinder.INSTANCE.getFlaggedChunks();
            Set<ChunkPos> traderChunks = ChunkFinder.INSTANCE.getTraderChunks();
            int susChunkCount = flaggedChunks.size();
            int traderChunkCount = traderChunks.size();
            String susChunkText;
            if (susChunkCount > 0) {
                ChunkPos firstSusChunk = flaggedChunks.iterator().next();
                int worldX = firstSusChunk.x * 16;
                int worldZ = firstSusChunk.z * 16;
                susChunkText = susChunkCount + " Sus (" + worldX + ", " + worldZ + ")";
            } else {
                susChunkText = "No Sus";
            }

            String traderChunkText;
            if (traderChunkCount > 0) {
                ChunkPos firstTraderChunk = traderChunks.iterator().next();
                int worldX = firstTraderChunk.x * 16;
                int worldZ = firstTraderChunk.z * 16;
                traderChunkText = traderChunkCount + " Trader (" + worldX + ", " + worldZ + ")";
            } else {
                traderChunkText = "No Trader";
            }

            float susChunkWidth = cellPadding * 2.0F + iconSize + iconTextSpacing + font.width(susChunkText) + 10.0F;
            float traderChunkWidth = cellPadding * 2.0F + iconSize + iconTextSpacing + font.width(traderChunkText) + 10.0F;
            float maxWidth = Math.max(susChunkWidth, traderChunkWidth);
            float totalHeight = (iconSize + verticalPadding * 2.0F) * 2.0F + itemSpacing + 4.0F;
            float totalWidth = this.widthAnimation.update(maxWidth);
            totalHeight = this.heightAnimation.update(totalHeight);
            this.width = totalWidth;
            this.height = totalHeight;
            DrawUtil.drawBlurHud(ctx.getMatrices(), this.x, this.y, totalWidth, totalHeight, 21.0F, BorderRadius.all(4.0F), ColorRGBA.WHITE);
            ctx.drawRoundedRect(this.x, this.y, totalWidth, totalHeight, BorderRadius.all(borderRadius), mainBgColor);
            float currentY = this.y + verticalPadding;
            float iconY = currentY + (iconSize + verticalPadding * 2.0F - iconSize) / 2.0F;
            float textY = currentY + (iconSize + verticalPadding * 2.0F - font.height()) / 2.0F;
            float currentX = this.x + cellPadding;
            ctx.enableScissor((int)this.x, (int)currentY, (int)(this.x + totalWidth), (int)(currentY + iconSize + verticalPadding * 2.0F));
            ctx.drawText(iconFont, "C", currentX, iconY, susChunkColor);
            currentX += iconSize + iconTextSpacing;
            ColorRGBA susTextColor = susChunkCount > 0 ? susChunkColor : grayTextColor;
            ctx.drawText(font, susChunkText, currentX, textY, susTextColor);
            ctx.disableScissor();
            currentY += iconSize + verticalPadding * 2.0F + itemSpacing;
            iconY = currentY + (iconSize + verticalPadding * 2.0F - iconSize) / 2.0F;
            textY = currentY + (iconSize + verticalPadding * 2.0F - font.height()) / 2.0F;
            currentX = this.x + cellPadding;
            ctx.enableScissor((int)this.x, (int)currentY, (int)(this.x + totalWidth), (int)(currentY + iconSize + verticalPadding * 2.0F));
            ctx.drawText(iconFont, "D", currentX, iconY, traderChunkColor);
            currentX += iconSize + iconTextSpacing;
            ColorRGBA traderTextColor = traderChunkCount > 0 ? traderChunkColor : grayTextColor;
            ctx.drawText(font, traderChunkText, currentX, textY, traderTextColor);
            ctx.disableScissor();
            ctx.drawRoundedBorder(this.x, this.y, totalWidth, totalHeight, 0.1F, BorderRadius.all(4.0F), theme.getForegroundStroke());
            DrawUtil.drawRoundedCorner(ctx.getMatrices(), this.x, this.y, totalWidth, totalHeight, 0.1F, 12.0F, theme.getColor(), BorderRadius.all(4.0F));
        }
    }
}
