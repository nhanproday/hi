package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Locale;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import zenith.zov.Zenith;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;

@ModuleAnnotation(
    name = "AutoAccept",
    category = Category.MISC,
    description = "Automatically accepts teleportation"
)
public final class AutoAccept extends Module {
    public static final AutoAccept INSTANCE = new AutoAccept();
    private final BooleanSetting onlyFriend = new BooleanSetting("Only Friends", false);

    private AutoAccept() {
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player != null && mc.world != null) {
            if (event.isReceive()) {
                if (event.getPacket() instanceof GameMessageS2CPacket packet) {
                    String raw = packet.content().getString().toLowerCase(Locale.ROOT);
                    if (raw.contains("teleport") || raw.contains("has requested teleport") || raw.contains("requests teleport to you")) {
                        if (this.onlyFriend.isEnabled()) {
                            boolean yes = false;

                            for (String friend : Zenith.getInstance().getFriendManager().getItems()) {
                                if (raw.contains(friend.toLowerCase(Locale.ROOT))) {
                                    yes = true;
                                    break;
                                }
                            }

                            if (!yes) {
                                return;
                            }
                        }

                        mc.player.networkHandler.sendChatCommand("tpaccept");
                    }
                }
            }
        }
    }
}
