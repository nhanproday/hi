package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;

@ModuleAnnotation(
    name = "HitBubbles",
    category = Category.RENDER,
    description = "Shows visual bubbles when hitting entities"
)
public final class HitBubbles extends Module implements IMinecraft {
    public static final HitBubbles INSTANCE = new HitBubbles();
    private final NumberSetting lifeTime = new NumberSetting("LifeTime", 30.0F, 1.0F, 150.0F, 1.0F);
    private final ArrayList<HitBubbles.HitBubble> bubbles = new ArrayList<>();

    private HitBubbles() {
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.player != null && mc.world != null) {
            RenderSystem.disableDepthTest();
            ArrayList<HitBubbles.HitBubble> bubblesCopy = Lists.newArrayList(this.bubbles);
            bubblesCopy.forEach(
                b -> {
                    MatrixStack matrixStack = event.getMatrix();
                    matrixStack.push();
                    matrixStack.translate(
                        (double)b.x - mc.getEntityRenderDispatcher().camera.getPos().getX(),
                        (double)b.y - mc.getEntityRenderDispatcher().camera.getPos().getY(),
                        (double)b.z - mc.getEntityRenderDispatcher().camera.getPos().getZ()
                    );
                    matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(b.yaw));
                    matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(b.pitch));
                    this.drawBubble(matrixStack, (float)(-b.life) / 4.0F, (float)b.life / 1500.0F);
                    matrixStack.pop();
                }
            );
            RenderSystem.enableDepthTest();
            this.bubbles.removeIf(b -> (float)b.life > this.lifeTime.getCurrent() * 50.0F);
        }
    }

    public void addHitBubble(Vec3d point, float yaw, float pitch) {
        if (point != null) {
            this.bubbles.add(new HitBubbles.HitBubble((float)point.x, (float)point.y, (float)point.z, -yaw, pitch, 0L));
        }
    }

    private void drawBubble(MatrixStack matrixStack, float size, float alpha) {
    }

    public static record HitBubble(float x, float y, float z, float yaw, float pitch, long life) {
    }
}
