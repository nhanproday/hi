package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.Zenith;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;

@ModuleAnnotation(
    name = "DiscordRPC",
    category = Category.MISC,
    description = "Shows your game status on Discord"
)
public final class DiscordRPCModule extends Module {
    public static final DiscordRPCModule INSTANCE = new DiscordRPCModule();
    private final BooleanSetting showDetails = new BooleanSetting("Show Details", true);
    private final BooleanSetting showButtons = new BooleanSetting("Show Buttons", true);
    private final ModeSetting status = new ModeSetting("Status", "Playing Zenith DLC", "In Menu", "In Game");

    private DiscordRPCModule() {
    }

    @Override
    public void onEnable() {
        if (Zenith.getInstance().getDiscordManager() != null) {
            Zenith.getInstance().getDiscordManager().init();
            Zenith.getInstance().getDiscordManager().forceUpdatePresence();
        }
    }

    @Override
    public void onDisable() {
        if (Zenith.getInstance().getDiscordManager() != null) {
            Zenith.getInstance().getDiscordManager().stopRPC();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player != null && mc.player.age % 100 == 0) {
            this.updatePresence();
        }
    }

    private void updatePresence() {
        if (Zenith.getInstance().getDiscordManager() != null && this.isEnabled()) {
            Zenith.getInstance().getDiscordManager().updatePresence();
        }
    }

    public boolean isShowDetails() {
        return this.showDetails.isEnabled();
    }

    public boolean isShowButtons() {
        return this.showButtons.isEnabled();
    }

    public String getStatus() {
        return this.status.get();
    }
}
