package zenith.zov.client.hud.elements.component;

import by.saskkeee.user.UserInfo;
import java.util.ArrayList;
import java.util.List;
import zenith.zov.Zenith;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.hud.elements.HudElement;
import zenith.zov.client.hud.elements.draggable.DraggableHudElement;
import zenith.zov.utility.game.other.TextUtil;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

public class WatermarkComponent extends DraggableHudElement {
    private final List<HudElement> elements = new ArrayList<>();

    public WatermarkComponent(
        String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align
    ) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        float iconSize = 7.0F;
        float elementSpacing = 1.0F;
        float iconTextSpacing = 4.0F;
        float cellPadding = 5.0F;
        float borderRadius = 4.0F;
        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA mainBgColor = theme.getForegroundColor();
        ColorRGBA highlightBgColor = theme.getForegroundLight();
        ColorRGBA iconColor = theme.getColor();
        ColorRGBA textColor = theme.getWhite();
        Font font = Fonts.MEDIUM.getFont(6.0F);
        this.elements.clear();
        this.elements.add(new HudElement("5", () -> "", ""));
        this.elements.add(new HudElement("2", () -> String.valueOf(UserInfo.getUsername())));
        this.elements.add(new HudElement("G", () -> String.valueOf(mc.getCurrentFps()), "fps"));
        this.elements
            .add(
                new HudElement(
                    "H",
                    () -> mc.player.networkHandler.getServerInfo() != null && mc.player.networkHandler.getPlayerListEntry(mc.player.getUuid()) != null
                            ? String.valueOf(mc.player.networkHandler.getPlayerListEntry(mc.player.getUuid()).getLatency())
                            : "0",
                    "ms"
                )
            );
        this.elements
            .add(
                new HudElement(
                    "I",
                    () -> mc.player.networkHandler.getServerInfo() == null
                            ? "20"
                            : TextUtil.formatNumber((double)Zenith.getInstance().getServerHandler().getTPS()).replace(",", ".").replace(".0", ""),
                    "tps"
                )
            );
        float totalWidth = 0.0F;

        for (HudElement el : this.elements) {
            el.calculateWidth(font, iconSize, cellPadding, iconTextSpacing);
            totalWidth += el.getWidth();
        }

        totalWidth += 4.0F;
        float totalHeight = 17.0F;
        this.width = totalWidth;
        this.height = totalHeight;
        DrawUtil.drawBlurHud(ctx.getMatrices(), this.x, this.y, this.width, this.height, 21.0F, BorderRadius.all(4.0F), ColorRGBA.WHITE);
        float currentX = this.x;

        for (int i = 0; i < this.elements.size(); i++) {
            HudElement el = this.elements.get(i);
            BorderRadius r = i == 0
                ? BorderRadius.left(borderRadius, borderRadius)
                : (i == this.elements.size() - 1 ? BorderRadius.right(borderRadius, borderRadius) : BorderRadius.ZERO);
            ctx.drawRoundedRect(
                currentX, this.y, el.getWidth() + (float)(i == this.elements.size() - 1 ? 4 : 0), totalHeight, r, i % 2 == 0 ? highlightBgColor : mainBgColor
            );
            el.drawContent(ctx, currentX + (float)(i == 0 ? 4 : 0), this.y, totalHeight, iconSize, iconTextSpacing, iconColor, textColor, font);
            currentX += el.getWidth();
        }

        ctx.drawRoundedBorder(this.x, this.y, totalWidth, totalHeight, 0.01F, BorderRadius.all(4.0F), theme.getForegroundStroke());
        DrawUtil.drawRoundedCorner(ctx.getMatrices(), this.x, this.y, totalWidth, totalHeight, 0.01F, 12.0F, theme.getColor(), BorderRadius.all(4.0F));
    }
}
