package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import lombok.Generated;
import zenith.zov.base.events.impl.entity.EventEntityColor;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ColorSetting;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

@ModuleAnnotation(
    name = "Anti Invisible",
    category = Category.RENDER,
    description = "Shows invisible players"
)
public final class AntiInvisible extends Module {
    public static final AntiInvisible INSTANCE = new AntiInvisible();
    private final ColorSetting colorSetting = new ColorSetting("Color", ColorRGBA.WHITE.mulAlpha(0.5F));

    private AntiInvisible() {
    }

    @EventTarget
    public void onEntityColor(EventEntityColor e) {
        e.setColor(this.colorSetting.getColor().getRGB());
        e.cancel();
    }

    @Generated
    public ColorSetting getColorSetting() {
        return this.colorSetting;
    }
}
