package zenith.zov.client.modules.impl.render;

import java.util.List;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.MultiBooleanSetting;

@ModuleAnnotation(
    name = "NoRender",
    category = Category.RENDER,
    description = "Removes unnecessary elements from screen"
)
public final class NoRender extends Module {
    public static final NoRender INSTANCE = new NoRender();
    private final MultiBooleanSetting settings = MultiBooleanSetting.create("Remove", List.of("Fire", "Bad Effects"));

    private NoRender() {
    }

    public boolean isRemoveFire() {
        return this.isEnabled() && this.settings.isEnable(0);
    }

    public boolean isRemoveBadEffect() {
        return this.isEnabled() && this.settings.isEnable(1);
    }
}
