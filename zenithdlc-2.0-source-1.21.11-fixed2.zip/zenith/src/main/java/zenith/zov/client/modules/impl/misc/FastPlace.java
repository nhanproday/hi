package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import zenith.zov.base.events.impl.player.EventItemUseCooldown;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(
    name = "FastPlace",
    category = Category.MISC,
    description = "Spams use action"
)
public final class FastPlace extends Module {
    public static final FastPlace INSTANCE = new FastPlace();
    private final BooleanSetting onlyXP = new BooleanSetting("Only XP", false);
    private final BooleanSetting allowBlocks = new BooleanSetting("Blocks", true);
    private final BooleanSetting allowItems = new BooleanSetting("Items", true);
    private final NumberSetting useDelay = new NumberSetting("Delay", 0.0F, 0.0F, 10.0F, 1.0F);

    private FastPlace() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onItemUseCooldown(EventItemUseCooldown event) {
        if (mc.player != null && mc.world != null) {
            ItemStack getMainHandStack = mc.player.getMainHandStack();
            ItemStack getItemUseTime = mc.player.getOffHandStack();
            Item item = getMainHandStack.getItem();
            Item item2 = mc.player.getOffHandStack().getItem();
            if (getMainHandStack.isOf(Items.EXPERIENCE_BOTTLE) || getItemUseTime.isOf(Items.EXPERIENCE_BOTTLE) || !this.onlyXP.isEnabled()) {
                if (!this.onlyXP.isEnabled()) {
                    if (!(item instanceof BlockItem) && !(item2 instanceof BlockItem)) {
                        if (!this.allowItems.isEnabled()) {
                            return;
                        }
                    } else if (!this.allowBlocks.isEnabled()) {
                        return;
                    }
                }

                if (item.getComponents().get(DataComponentTypes.FOOD) == null) {
                    if (item2.getComponents().get(DataComponentTypes.FOOD) == null) {
                        if (!getMainHandStack.isOf(Items.RESPAWN_ANCHOR)
                            && !getMainHandStack.isOf(Items.GLOWSTONE)
                            && !getItemUseTime.isOf(Items.RESPAWN_ANCHOR)
                            && !getItemUseTime.isOf(Items.GLOWSTONE)) {
                            if (!(item instanceof RangedWeaponItem) && !(item2 instanceof RangedWeaponItem)) {
                                event.setCooldown((int)this.useDelay.getCurrent());
                            }
                        }
                    }
                }
            }
        }
    }
}
