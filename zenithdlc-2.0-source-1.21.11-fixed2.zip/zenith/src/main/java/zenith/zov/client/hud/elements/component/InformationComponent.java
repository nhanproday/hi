package zenith.zov.client.hud.elements.component;

import java.util.Locale;
import zenith.zov.Zenith;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.hud.elements.draggable.DraggableHudElement;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

public class InformationComponent extends DraggableHudElement {
    Animation cordsWidthAnimation = new Animation(200L, Easing.QUAD_IN_OUT);
    Animation speedWidthAnimation = new Animation(200L, Easing.QUAD_IN_OUT);

    public InformationComponent(
        String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, DraggableHudElement.Align align
    ) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        float iconSize = 6.0F;
        float verticalPadding = 6.0F;
        float iconTextSpacing = 4.0F;
        float cellPadding = 5.0F;
        float borderRadius = 4.0F;
        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA mainBgColor = theme.getForegroundColor();
        ColorRGBA highlightBgColor = theme.getForegroundLight();
        ColorRGBA iconColor = theme.getColor();
        ColorRGBA textColor = theme.getWhite();
        ColorRGBA grayTextColor = theme.getGrayLight();
        Font font = Fonts.MEDIUM.getFont(6.0F);
        double speed = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ);
        String coordsText = String.format(
            Locale.US, "%d y%d z%d", (int)mc.player.getX(), (int)mc.player.getY(), (int)mc.player.getZ()
        );
        String speedText = String.format("%.2f", speed * 20.0).replace(",", ".");
        float coordsWidth = cellPadding * 2.0F + iconSize + iconTextSpacing + (float)coordsText.length() * 3.8F;
        float speedWidth = cellPadding * 2.0F + iconSize + iconTextSpacing + font.width(speedText) + font.width("bps");
        coordsWidth = this.cordsWidthAnimation.update(coordsWidth);
        speedWidth = this.speedWidthAnimation.update(speedWidth);
        float totalWidth = coordsWidth + speedWidth;
        float totalHeight = iconSize + verticalPadding * 2.0F;
        this.width = totalWidth;
        this.height = totalHeight;
        DrawUtil.drawBlurHud(ctx.getMatrices(), this.x, this.y, coordsWidth + speedWidth, totalHeight, 21.0F, BorderRadius.all(4.0F), ColorRGBA.WHITE);
        ctx.drawRoundedRect(this.x, this.y, coordsWidth, totalHeight, BorderRadius.left(borderRadius, borderRadius), highlightBgColor);
        ctx.drawRoundedRect(this.x + coordsWidth, this.y, speedWidth, totalHeight, BorderRadius.right(borderRadius, borderRadius), mainBgColor);
        ctx.enableScissor((int)this.x, (int)this.y, (int)(this.x + coordsWidth), (int)(this.y + this.height));
        float currentX = this.x + cellPadding;
        float iconY = this.y + (totalHeight - iconSize) / 2.0F;
        float textY = this.y + (totalHeight - font.height()) / 2.0F;
        Font iconFont = Fonts.ICONS.getFont(6.0F);
        ctx.drawText(iconFont, "J", currentX, iconY, iconColor);
        currentX += iconSize + iconTextSpacing;
        currentX = this.drawPrefixedText(ctx, font, "x", String.valueOf((int)mc.player.getX()), currentX, textY, grayTextColor, textColor);
        currentX = this.drawPrefixedText(ctx, font, " y", String.valueOf((int)mc.player.getY()), currentX, textY, grayTextColor, textColor);
        currentX = this.drawPrefixedText(ctx, font, " z", String.valueOf((int)mc.player.getZ()), currentX, textY, grayTextColor, textColor);
        ctx.disableScissor();
        currentX = this.x + coordsWidth + cellPadding;
        ctx.enableScissor((int)currentX, (int)this.y, (int)(currentX + speedWidth), (int)(this.y + this.height));
        ctx.drawText(iconFont, "K", currentX, iconY, iconColor);
        currentX += iconSize + iconTextSpacing;
        currentX = this.drawPrefixedText(ctx, font, speedText, "bps", currentX, textY, textColor, grayTextColor);
        ctx.disableScissor();
        ctx.drawRoundedBorder(this.x, this.y, coordsWidth + speedWidth, totalHeight, 0.1F, BorderRadius.all(4.0F), theme.getForegroundStroke());
        DrawUtil.drawRoundedCorner(
            ctx.getMatrices(), this.x, this.y, coordsWidth + speedWidth, totalHeight, 0.1F, 12.0F, theme.getColor(), BorderRadius.all(4.0F)
        );
    }

    private float drawPrefixedText(CustomDrawContext ctx, Font font, String prefix, String value, float x, float y, ColorRGBA prefixColor, ColorRGBA valueColor) {
        ctx.drawText(font, prefix, x, y, prefixColor);
        float prefixWidth = font.width(prefix);
        ctx.drawText(font, value, x + prefixWidth, y, valueColor);
        return x + (float)prefix.length() * 3.8F + (float)value.length() * 3.8F;
    }
}
