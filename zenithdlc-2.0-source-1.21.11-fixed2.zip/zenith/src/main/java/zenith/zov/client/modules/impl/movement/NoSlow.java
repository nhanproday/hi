package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.Hand;
import zenith.zov.base.events.impl.player.EventSlowWalking;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.game.player.PlayerIntersectionUtil;

@ModuleAnnotation(
    name = "NoSlow",
    category = Category.MOVEMENT,
    description = "Removes slowdown while eating"
)
public final class NoSlow extends Module {
    public static final NoSlow INSTANCE = new NoSlow();
    private final ModeSetting mode = new ModeSetting("Mode");
    private final ModeSetting.Value grimNew = new ModeSetting.Value(this.mode, "Grim New");
    private final ModeSetting.Value hw = new ModeSetting.Value(this.mode, "Grim old").select();
    private BooleanSetting sprint = new BooleanSetting("Sprint", true, this.hw::isSelected);
    private int ticks = 0;

    private NoSlow() {
    }

    @EventTarget
    public void onItemUse(EventSlowWalking e) {
        if (this.grimNew.isSelected() && mc.player.getItemUseTime() % 2 == 0) {
            e.setCancelled(true);
        }

        if (this.hw.isSelected()) {
            Hand hand = mc.player.getActiveHand();
            if (this.sprint.isEnabled()) {
                mc.player
                    .setSprinting(
                        mc.player.canSprint()
                            && mc.player.isWalking()
                            && !mc.player.isBlind()
                            && !mc.player.isGliding()
                            && (!mc.player.shouldSlowDown() || mc.player.isSubmergedInWater())
                    );
            }

            PlayerIntersectionUtil.useItem(hand.equals(Hand.MAIN_HAND) ? Hand.OFF_HAND : Hand.MAIN_HAND);
            e.setCancelled(true);
        }
    }

    @EventTarget
    public void update(EventUpdate tickEvent) {
        if (!mc.player.isUsingItem() || !mc.player.isOnGround()) {
            this.ticks = 0;
        }
    }
}
