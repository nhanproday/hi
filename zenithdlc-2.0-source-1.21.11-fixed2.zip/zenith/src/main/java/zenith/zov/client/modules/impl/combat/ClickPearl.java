package zenith.zov.client.modules.impl.combat;

import net.minecraft.item.Items;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.game.player.PlayerInventoryUtil;

@ModuleAnnotation(
    name = "ClickPearl",
    category = Category.COMBAT,
    description = "Throws pearl if not in hands"
)
public final class ClickPearl extends Module {
    public static final ClickPearl INSTANCE = new ClickPearl();

    private ClickPearl() {
    }

    @Override
    public void onEnable() {
        PlayerInventoryUtil.swapAndUse(Items.ENDER_PEARL);
        super.onEnable();
        this.toggle();
    }
}
