package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import zenith.zov.Zenith;
import zenith.zov.base.events.impl.player.EventMoveInput;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.game.player.MovingUtil;
import zenith.zov.utility.game.player.PlayerIntersectionUtil;

@ModuleAnnotation(
    name = "ElytraRecast",
    description = "Allows higher jumping with elytra",
    category = Category.MOVEMENT
)
public final class ElytraRecast extends Module {
    public static final ElytraRecast INSTANCE = new ElytraRecast();
    private int groundTick = 0;
    private boolean changed = false;

    private ElytraRecast() {
    }

    @EventTarget
    public void update(EventMoveInput eventUpdate) {
        if (mc.player.isUsingItem()) {
            if (Zenith.getInstance().getServerHandler().isServerSprint()) {
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, Mode.STOP_SPRINTING));
                mc.player.setSprinting(false);
            }

            this.groundTick = 5;
        } else if (this.groundTick > 0) {
            this.groundTick--;
            return;
        }

        if (!mc.player.isUsingItem()
            && !mc.player.isTouchingWater()
            && mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem().equals(Items.ELYTRA)
            && MovingUtil.hasPlayerMovement()) {
            if (mc.player.isOnGround() && mc.player.isWalking()) {
                if (mc.player.canSprint()
                    && mc.player.isWalking()
                    && !mc.player.isBlind()
                    && !mc.player.isUsingItem()
                    && (!mc.player.shouldSlowDown() || mc.player.isSubmergedInWater())) {
                    if (!mc.player.isSprinting() && Zenith.getInstance().getServerHandler().isServerSprint()) {
                        mc.player.setSprinting(true);
                    }

                    if (!Zenith.getInstance().getServerHandler().isServerSprint()) {
                        mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, Mode.START_SPRINTING));
                        mc.player.setSprinting(true);
                        this.changed = true;
                    }
                } else {
                    if (Zenith.getInstance().getServerHandler().isServerSprint()) {
                        mc.player.lastSprinting = true;
                        mc.player.setSprinting(false);
                    }

                    mc.player.setSprinting(false);
                }

                mc.player.jump();
            } else if (!mc.player.isGliding()) {
                PlayerIntersectionUtil.startFallFlying();
            }
        } else if (this.changed && Zenith.getInstance().getServerHandler().isServerSprint()) {
            mc.player.lastSprinting = true;
            mc.player.setSprinting(false);
            this.changed = false;
        }

        if (this.groundTick > 0) {
            this.groundTick--;
        }
    }

    @Override
    public void onDisable() {
        if (Zenith.getInstance().getServerHandler().isServerSprint() && this.changed) {
            mc.player.lastSprinting = true;
            mc.player.setSprinting(false);
        }

        super.onDisable();
    }
}
