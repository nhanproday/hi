package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.interfaces.IMinecraft;

@ModuleAnnotation(
    name = "CrystalOptimizer",
    category = Category.CRYSTAL,
    description = "Makes your crystals disappear faster client-side so you can place crystals faster"
)
public final class CrystalOptimizer extends Module implements IMinecraft {
    public static final CrystalOptimizer INSTANCE = new CrystalOptimizer();

    private CrystalOptimizer() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onPacketSend(EventPacket event) {
        if (event.isSent() && event.getPacket() instanceof PlayerInteractEntityC2SPacket interactPacket) {
            interactPacket.handle(
                new Handler() {
                    public void interact(Hand hand) {
                    }

                    public void interactAt(Hand hand, Vec3d pos) {
                    }

                    public void attack() {
                        if (IMinecraft.mc.crosshairTarget != null) {
                            if (IMinecraft.mc.crosshairTarget.getType() == Type.ENTITY
                                && IMinecraft.mc.crosshairTarget instanceof EntityHitResult hit
                                && hit.getEntity() instanceof EndCrystalEntity) {
                                StatusEffectInstance weakness = IMinecraft.mc.player.getStatusEffect(StatusEffects.WEAKNESS);
                                StatusEffectInstance strength = IMinecraft.mc.player.getStatusEffect(StatusEffects.STRENGTH);
                                if (weakness != null
                                    && (strength == null || strength.getAmplifier() <= weakness.getAmplifier())
                                    && !CrystalOptimizer.this.isTool(IMinecraft.mc.player.getMainHandStack())) {
                                    return;
                                }

                                if (IMinecraft.mc.world != null) {
                                    hit.getEntity().setRemoved(RemovalReason.KILLED);
                                    hit.getEntity().onRemoved();
                                    IMinecraft.mc.world.removeEntity(hit.getEntity().getId(), RemovalReason.KILLED);
                                }
                            }
                        }
                    }
                }
            );
        }
    }

    private boolean isTool(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.DIAMOND_PICKAXE
            || item == Items.NETHERITE_PICKAXE
            || item == Items.DIAMOND_AXE
            || item == Items.NETHERITE_AXE
            || item == Items.DIAMOND_SHOVEL
            || item == Items.NETHERITE_SHOVEL
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD
            || item == Items.DIAMOND_HOE
            || item == Items.NETHERITE_HOE
            || item == Items.IRON_PICKAXE
            || item == Items.IRON_AXE
            || item == Items.IRON_SHOVEL
            || item == Items.IRON_SWORD
            || item == Items.IRON_HOE
            || item == Items.STONE_PICKAXE
            || item == Items.STONE_AXE
            || item == Items.STONE_SHOVEL
            || item == Items.STONE_SWORD
            || item == Items.STONE_HOE
            || item == Items.WOODEN_PICKAXE
            || item == Items.WOODEN_AXE
            || item == Items.WOODEN_SHOVEL
            || item == Items.WOODEN_SWORD
            || item == Items.WOODEN_HOE
            || item == Items.GOLDEN_PICKAXE
            || item == Items.GOLDEN_AXE
            || item == Items.GOLDEN_SHOVEL
            || item == Items.GOLDEN_SWORD
            || item == Items.GOLDEN_HOE
            || item == Items.MACE;
    }
}
