package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import zenith.zov.base.events.impl.other.EventClickSlot;
import zenith.zov.base.events.impl.other.EventCloseScreen;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.game.player.MovingUtil;
import zenith.zov.utility.game.player.PlayerIntersectionUtil;
import zenith.zov.utility.game.player.PlayerInventoryComponent;
import zenith.zov.utility.game.player.PlayerInventoryUtil;
import zenith.zov.utility.game.server.AutoBuyUtil;

@ModuleAnnotation(
    name = "Gui Walk",
    category = Category.MOVEMENT,
    description = "Can walk in inventory or container"
)
public final class GuiWalk extends Module {
    public static final GuiWalk INSTANCE = new GuiWalk();
    private final List<Packet<?>> packets = new ArrayList<>();

    private GuiWalk() {
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        Packet var10000 = e.getPacket();
        Objects.requireNonNull(var10000);
        Packet var2 = var10000;
        byte var3 = 0;

        while (true) {
            switch (SwitchBootstraps.typeSwitch<"typeSwitch",ClickSlotC2SPacket,CloseScreenS2CPacket>(var2, var3)) {
                case 0:
                    ClickSlotC2SPacket slot = (ClickSlotC2SPacket)var2;
                    if ((!this.packets.isEmpty() || MovingUtil.hasPlayerMovement()) && PlayerInventoryComponent.shouldSkipExecution()) {
                        this.packets.add(slot);
                        e.cancel();
                        return;
                    }

                    var3 = 1;
                    break;
                case 1:
                    CloseScreenS2CPacket screen = (CloseScreenS2CPacket)var2;
                    if (screen.getSyncId() != 0) {
                        var3 = 2;
                        break;
                    } else {
                        e.cancel();
                        return;
                    }
                default:
                    return;
            }
        }
    }

    @EventTarget
    public void onTick(EventUpdate e) {
        if (!PlayerInventoryUtil.isServerScreen()
            && PlayerInventoryComponent.shouldSkipExecution()
            && (!this.packets.isEmpty() || mc.player.currentScreenHandler.getCursorStack().isEmpty())) {
            PlayerInventoryComponent.updateMoveKeys();
        }
    }

    @EventTarget
    public void onClickSlot(EventClickSlot e) {
        System.out.println(e.getSlotId() + " " + e.getButton());
        if (mc.player.currentScreenHandler.isValid(e.getSlotId())) {
            Slot slot = mc.player.currentScreenHandler.getSlot(e.getSlotId());
            System.out.println(AutoBuyUtil.getKey(slot.getStack()));
        }

        SlotActionType actionType = e.getActionType();
        if ((!this.packets.isEmpty() || MovingUtil.hasPlayerMovement())
            && e.getButton() == 1
            && !actionType.equals(SlotActionType.SWAP)
            && !actionType.equals(SlotActionType.THROW)) {
            e.setCancelled(true);
        }
    }

    @EventTarget
    public void onCloseScreen(EventCloseScreen e) {
        if (!this.packets.isEmpty()) {
            PlayerInventoryComponent.addTask(() -> {
                this.packets.forEach(PlayerIntersectionUtil::sendPacketWithOutEvent);
                this.packets.clear();
                PlayerInventoryUtil.updateSlots();
            });
        }
    }
}
