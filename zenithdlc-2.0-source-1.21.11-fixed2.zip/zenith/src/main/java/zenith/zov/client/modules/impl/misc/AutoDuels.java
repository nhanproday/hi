package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.math.Timer;

@ModuleAnnotation(
    name = "AutoDuels",
    category = Category.MISC,
    description = "Throws duel on RW"
)
public final class AutoDuels extends Module {
    public static final AutoDuels INSTANCE = new AutoDuels();
    private final ModeSetting mode = new ModeSetting("Kit");
    private final ModeSetting.Value shield = new ModeSetting.Value(this.mode, "Shields");
    private final ModeSetting.Value shipi = new ModeSetting.Value(this.mode, "Thorns");
    private final ModeSetting.Value bow = new ModeSetting.Value(this.mode, "Bow");
    private final ModeSetting.Value totem = new ModeSetting.Value(this.mode, "Totems");
    private final ModeSetting.Value noDebuff = new ModeSetting.Value(this.mode, "NoDebuff");
    private final ModeSetting.Value balls = new ModeSetting.Value(this.mode, "Balls");
    private final ModeSetting.Value classik = new ModeSetting.Value(this.mode, "Classic");
    private final ModeSetting.Value cheats = new ModeSetting.Value(this.mode, "Cheater Paradise");
    private final ModeSetting.Value nezer = new ModeSetting.Value(this.mode, "Nether");
    private final Timer timer;
    private final List<String> sent;

    private AutoDuels() {
        this.mode.setValue(this.classik);
        this.timer = new Timer();
        this.sent = new ArrayList<>();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        List<String> playerNames = new ArrayList<>();
        Collections.shuffle(playerNames);

        for (PlayerListEntry entry : mc.player.networkHandler.getPlayerList()) {
            playerNames.add(entry.getProfile().getName());
        }

        for (String name : playerNames) {
            if (this.timer.finished(750L) && !this.sent.contains(name) && !name.equals(mc.player.getNameForScoreboard())) {
                mc.player.networkHandler.sendChatCommand("duel " + name);
                this.sent.add(name);
                this.timer.reset();
            }
        }

        if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
            String title = mc.currentScreen.getTitle().getString();
            if (title.contains("Kit Selection")) {
                mc.interactionManager
                    .clickSlot(
                        mc.player.currentScreenHandler.syncId,
                        this.mode.getValues().indexOf(this.mode.getRandomEnabledElement()),
                        0,
                        SlotActionType.PICKUP,
                        mc.player
                    );
            } else if (title.contains("Duel Setup")) {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 0, 0, SlotActionType.PICKUP, mc.player);
            }
        }
    }

    @EventTarget
    public void onReceivePacket(EventPacket event) {
        if (event.isReceive()) {
            if (event.getPacket() instanceof GameMessageS2CPacket packet) {
                String msg = packet.content().getString();
                if (msg.contains("Accepted") && !msg.contains("not accepted")) {
                    this.sent.clear();
                    this.toggle();
                }

                if (msg.contains("duel") && (msg.contains("found") || msg.contains("started") || msg.contains("start"))) {
                    this.sent.clear();
                    this.toggle();
                }

                if (msg.contains("won") || msg.contains("lost") || msg.contains("draw")) {
                    this.sent.clear();
                    this.toggle();
                }

                if (msg.contains("Balance") || msg.contains("disabled requests")) {
                    event.cancel();
                }
            }
        }
    }

    @Override
    public void onEnable() {
        if (mc.player == null) {
            this.setEnabled(false);
        } else {
            this.timer.reset();
            super.onEnable();
        }
    }
}
