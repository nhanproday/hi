package zenith.zov.client.modules.api;

import lombok.Generated;

public enum Category {
    CRYSTAL("Crystal", "C"),
    COMBAT("Combat", "0"),
    MOVEMENT("Movement", "1"),
    PLAYER("Player", "2"),
    RENDER("Render", "3"),
    MISC("Misc", "4"),
    THEMES("Themes", "G"),
    CONFIGS("Configs", "W");

    private final String name;
    private final String icon;

    private Category(String name, String icon) {
        this.name = name;
        this.icon = icon;
    }

    @Generated
    public String getIcon() {
        return this.icon;
    }

    @Generated
    public String getName() {
        return this.name;
    }
}
