package zenith.zov.client.modules.api.setting.impl;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Type;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import zenith.zov.client.modules.api.setting.Setting;

public class ToolSelectSetting extends Setting {
    private List<String> toolsById;
    private static final Gson gson = new Gson();

    public void setToolsById(List<String> toolsById) {
        this.toolsById = toolsById;
    }

    public ToolSelectSetting(String name, List<String> toolsById) {
        this(name, toolsById, () -> true);
    }

    public ToolSelectSetting(String name, List<String> toolsById, Supplier<Boolean> visible) {
        super(name);
        this.toolsById = toolsById;
        this.setVisible(visible);
    }

    public List<String> getToolsById() {
        return this.toolsById;
    }

    public void add(String s) {
        if (!this.toolsById.contains(s)) {
            this.toolsById.add(s);
        }
    }

    public void remove(String s) {
        this.toolsById.remove(s);
    }

    public boolean contains(String s) {
        return this.toolsById.contains(s);
    }

    public void add(Item item) {
        if (this.isTool(item)) {
            this.add(item.getTranslationKey().replace("item.minecraft.", ""));
        }
    }

    public void remove(Item item) {
        if (this.isTool(item)) {
            this.remove(item.getTranslationKey().replace("item.minecraft.", ""));
        }
    }

    public boolean contains(Item item) {
        return this.isTool(item) ? this.contains(item.getTranslationKey().replace("item.minecraft.", "")) : false;
    }

    private boolean isTool(Item item) {
        return item == Items.DIAMOND_PICKAXE
            || item == Items.NETHERITE_PICKAXE
            || item == Items.DIAMOND_AXE
            || item == Items.NETHERITE_AXE
            || item == Items.DIAMOND_SHOVEL
            || item == Items.NETHERITE_SHOVEL
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD
            || item == Items.DIAMOND_HOE
            || item == Items.NETHERITE_HOE
            || item == Items.IRON_PICKAXE
            || item == Items.IRON_AXE
            || item == Items.IRON_SHOVEL
            || item == Items.IRON_SWORD
            || item == Items.IRON_HOE
            || item == Items.STONE_PICKAXE
            || item == Items.STONE_AXE
            || item == Items.STONE_SHOVEL
            || item == Items.STONE_SWORD
            || item == Items.STONE_HOE
            || item == Items.WOODEN_PICKAXE
            || item == Items.WOODEN_AXE
            || item == Items.WOODEN_SHOVEL
            || item == Items.WOODEN_SWORD
            || item == Items.WOODEN_HOE
            || item == Items.GOLDEN_PICKAXE
            || item == Items.GOLDEN_AXE
            || item == Items.GOLDEN_SHOVEL
            || item == Items.GOLDEN_SWORD
            || item == Items.GOLDEN_HOE
            || item == Items.MACE
            || item == Items.TOTEM_OF_UNDYING
            || item == Items.GOLDEN_APPLE
            || item == Items.ENCHANTED_GOLDEN_APPLE
            || item == Items.ENDER_PEARL
            || item == Items.ENDER_EYE
            || item == Items.END_CRYSTAL
            || item == Items.OBSIDIAN
            || item == Items.RESPAWN_ANCHOR
            || item == Items.GLOWSTONE
            || item == Items.SHIELD
            || item == Items.BOW
            || item == Items.CROSSBOW
            || item == Items.TRIDENT
            || item == Items.AMETHYST_SHARD
            || item == Items.ECHO_SHARD
            || item == Items.QUARTZ
            || item == Items.PRISMARINE_SHARD
            || item == Items.PRISMARINE_CRYSTALS;
    }

    public void clear() {
        this.toolsById.clear();
    }

    public boolean isEmpty() {
        return this.toolsById.isEmpty();
    }

    public int size() {
        return this.toolsById.size();
    }

    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.add(String.valueOf(this.name), gson.toJsonTree(this.getToolsById()));
    }

    @Override
    public void load(JsonObject propertiesObject) {
        Type listType = (new TypeToken<List<String>>() {
        }).getType();
        JsonElement jsonElement = propertiesObject.get(String.valueOf(this.name));
        if (jsonElement != null && jsonElement.isJsonArray()) {
            List<String> list = (List<String>)gson.fromJson(jsonElement, listType);
            this.setToolsById(list);
        }
    }
}
