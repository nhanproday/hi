package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ColorSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

@ModuleAnnotation(
    name = "EntityModifier",
    description = "Lets you customize the rendering of entities.",
    category = Category.RENDER
)
public class EntityModifierModule extends Module {
    public BooleanSetting players = new BooleanSetting("Players", "Whether or not to modify player rendering.", true);
    public ColorSetting playerColor = new ColorSetting("PlayerColor", new ColorRGBA(255, 255, 255, 255));
    public NumberSetting playerScale = new NumberSetting("PlayerScale", 1.0F, 0.0F, 10.0F, 0.1F);
    public BooleanSetting crystals = new BooleanSetting("Crystals", "Whether or not to modify crystal rendering.", true);
    public ColorSetting crystalColor = new ColorSetting("CrystalColor", new ColorRGBA(255, 255, 255, 255));
    public NumberSetting crystalScale = new NumberSetting("CrystalScale", 1.0F, 0.0F, 10.0F, 0.1F);
    public NumberSetting crystalSpeed = new NumberSetting("CrystalSpeed", 1.0F, 0.0F, 10.0F, 0.1F);
    public NumberSetting crystalBounce = new NumberSetting("CrystalBounce", 1.0F, 0.0F, 10.0F, 0.1F);
    public BooleanSetting items = new BooleanSetting("Items", "Whether or not to modify item rendering.", true);
    public ColorSetting itemColor = new ColorSetting("ItemColor", new ColorRGBA(255, 255, 255, 255));
    public BooleanSetting itemGlobal = new BooleanSetting("ItemGlobal", "Applies the modifications to every single item regardless of where it is.", false);

    @EventTarget
    public void onRender3D(EventRender3D event) {
    }
}
