package zenith.zov.client.modules.impl.misc;

import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(
    name = "NoInteract",
    category = Category.MISC,
    description = "Prevents opening containers"
)
public final class NoInteract extends Module {
    public static final NoInteract INSTANCE = new NoInteract();

    private NoInteract() {
    }
}
