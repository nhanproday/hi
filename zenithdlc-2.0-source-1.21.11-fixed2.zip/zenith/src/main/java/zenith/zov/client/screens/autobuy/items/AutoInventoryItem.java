package zenith.zov.client.screens.autobuy.items;

import com.google.gson.JsonObject;
import lombok.Generated;
import net.minecraft.item.ItemStack;
import zenith.zov.base.autobuy.item.ItemBuy;

public class AutoInventoryItem {
    private final ItemBuy itemBuy;
    private long maxSumBuy = 0L;
    private int countBuy = 1;
    private boolean selected = false;
    private int slotId;

    public AutoInventoryItem(ItemBuy itemBuy) {
        this.itemBuy = itemBuy;
    }

    public void toggleSelected() {
        this.selected = !this.selected;
    }

    public AutoInventoryItem copy() {
        AutoInventoryItem copy = new AutoInventoryItem(this.itemBuy);
        copy.maxSumBuy = this.maxSumBuy;
        copy.countBuy = this.countBuy;
        copy.selected = this.selected;
        return copy;
    }

    public JsonObject save() {
        JsonObject obj = new JsonObject();
        obj.addProperty("maxSumBuy", this.maxSumBuy);
        obj.addProperty("countBuy", this.countBuy);
        obj.addProperty("selected", this.selected);
        obj.addProperty("slotId", this.slotId);
        return obj;
    }

    public void load(JsonObject obj) {
        if (obj.has("maxSumBuy")) {
            this.maxSumBuy = obj.get("maxSumBuy").getAsLong();
        }

        if (obj.has("countBuy")) {
            this.countBuy = obj.get("countBuy").getAsInt();
        }

        if (obj.has("selected")) {
            this.selected = obj.get("selected").getAsBoolean();
        }

        if (obj.has("slotId")) {
            this.slotId = obj.get("slotId").getAsInt();
        }
    }

    public boolean isBuy(ItemStack stack) {
        return this.itemBuy.isBuy(stack);
    }

    @Generated
    public ItemBuy getItemBuy() {
        return this.itemBuy;
    }

    @Generated
    public long getMaxSumBuy() {
        return this.maxSumBuy;
    }

    @Generated
    public int getCountBuy() {
        return this.countBuy;
    }

    @Generated
    public boolean isSelected() {
        return this.selected;
    }

    @Generated
    public int getSlotId() {
        return this.slotId;
    }

    @Generated
    public void setMaxSumBuy(long maxSumBuy) {
        this.maxSumBuy = maxSumBuy;
    }

    @Generated
    public void setCountBuy(int countBuy) {
        this.countBuy = countBuy;
    }

    @Generated
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Generated
    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }
}
