package zenith.zov;

import by.saskkeee.annotations.CompileToNative;
import by.saskkeee.annotations.Entrypoint;
import by.saskkeee.annotations.vmprotect.CompileType;
import by.saskkeee.annotations.vmprotect.VMProtect;
import java.io.File;
import lombok.Generated;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import zenith.zov.base.autobuy.AutoBuyManager;
import zenith.zov.base.comand.CommandManager;
import zenith.zov.base.config.ConfigManager;
import zenith.zov.base.filemanager.impl.FriendManager;
import zenith.zov.base.filemanager.impl.StaffManager;
import zenith.zov.base.modules.ModuleManager;
import zenith.zov.base.notify.NotifyManager;
import zenith.zov.base.repository.RCTRepository;
import zenith.zov.base.request.ScriptManager;
import zenith.zov.base.rotation.RotationManager;
import zenith.zov.base.rotation.deeplearnig.DeepLearningManager;
import zenith.zov.base.theme.ThemeManager;
import zenith.zov.client.screens.autobuy.items.AutoInventoryBuyScreen;
import zenith.zov.client.screens.menu.MenuScreen;
import zenith.zov.utility.discord.DiscordManager;
import zenith.zov.utility.game.server.ServerHandler;
import zenith.zov.utility.render.display.shader.DrawUtil;
import zenith.zov.utility.render.display.shader.GlProgram;

@Entrypoint
public enum Zenith {
    INSTANCE;

    public static final String NAME = "Zenith";
    public static final String VER = "2.0";
    public static final String TYPE = "DEV";
    private static final String MOD_ID = "Zenith".toLowerCase();
    public static final File DIRECTORY = new File(MinecraftClient.getInstance().runDirectory, "Zenith");
    private ModuleManager moduleManager;
    private ThemeManager themeManager;
    private MenuScreen menuScreen;
    private ScriptManager scriptManager;
    private AutoInventoryBuyScreen autoInventoryBuyScreen;
    private ServerHandler serverHandler;
    private FriendManager friendManager;
    private StaffManager staffManager;
    private DeepLearningManager deepLearningManager;
    private RotationManager rotationManager;
    private AutoBuyManager autoBuyManager;
    private NotifyManager notifyManager;
    private CommandManager commandManager;
    private ConfigManager configManager;
    private RCTRepository rctRepository;
    private DiscordManager discordManager;

    @CompileToNative
    @VMProtect(
        type = CompileType.ULTRA
    )
    public void init() {
        this.friendManager = new FriendManager();
        this.staffManager = new StaffManager();
        this.notifyManager = new NotifyManager();
        this.serverHandler = new ServerHandler();
        this.rctRepository = new RCTRepository();
        this.themeManager = new ThemeManager();
        this.moduleManager = new ModuleManager();
        this.discordManager = new DiscordManager();
        this.deepLearningManager = new DeepLearningManager();
        this.rotationManager = new RotationManager();
        this.autoBuyManager = new AutoBuyManager();
        this.commandManager = new CommandManager();
        this.scriptManager = new ScriptManager();
        this.menuScreen = new MenuScreen();
        this.configManager = new ConfigManager();
        this.menuScreen.initialize();
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            public Identifier getFabricId() {
                return Zenith.id("after_shader_load");
            }

            public void reload(ResourceManager manager) {
                GlProgram.loadAndSetupPrograms();
            }
        });
        DrawUtil.initializeShaders();
    }

    public void shutdown() {
        this.friendManager.save();
        this.staffManager.save();
        this.configManager.save();
        if (this.discordManager != null) {
            this.discordManager.stopRPC();
        }
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    public static Zenith getInstance() {
        return INSTANCE;
    }

    public RCTRepository getRCTRepository() {
        return this.rctRepository;
    }

    @Generated
    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    @Generated
    public ThemeManager getThemeManager() {
        return this.themeManager;
    }

    @Generated
    public MenuScreen getMenuScreen() {
        return this.menuScreen;
    }

    @Generated
    public ScriptManager getScriptManager() {
        return this.scriptManager;
    }

    @Generated
    public AutoInventoryBuyScreen getAutoInventoryBuyScreen() {
        return this.autoInventoryBuyScreen;
    }

    @Generated
    public ServerHandler getServerHandler() {
        return this.serverHandler;
    }

    @Generated
    public FriendManager getFriendManager() {
        return this.friendManager;
    }

    @Generated
    public StaffManager getStaffManager() {
        return this.staffManager;
    }

    @Generated
    public DeepLearningManager getDeepLearningManager() {
        return this.deepLearningManager;
    }

    @Generated
    public RotationManager getRotationManager() {
        return this.rotationManager;
    }

    @Generated
    public AutoBuyManager getAutoBuyManager() {
        return this.autoBuyManager;
    }

    @Generated
    public NotifyManager getNotifyManager() {
        return this.notifyManager;
    }

    @Generated
    public CommandManager getCommandManager() {
        return this.commandManager;
    }

    @Generated
    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    @Generated
    public DiscordManager getDiscordManager() {
        return this.discordManager;
    }
}
